/* adCraft — Frontend App v4 */

// ── State ──────────────────────────────────────────────────────────────────
let allFormats        = [];
let sources           = [];
let selectedSrcs      = new Set();
let generationCount   = 0;
let libraryItems      = [];
let currentLibraryId  = null;
let currentArtifactItem = null;

// Prompt-Editor State
let peState = {
  formatId: null,
  data:     null,    // { activeId, versions: [...] }
  selected: null,    // currently displayed version id
  dirty:    false,   // unsaved edits in current version
};

// ── Init ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadProvider();
  loadFormats();
  loadSources();
  loadLibrary();
  initNav();
  initSourceTabs();
  initSourceActions();
  initSvSourceActions();
  initGenerate();
  initWebSearchToggle();
  initLibraryEvents();
  initPromptEditorModal();
  initPreferences();
  initComplianceToggle();
  document.getElementById('heroStartBtn').addEventListener('click', () => switchView('generator'));
  window.addEventListener('message', onIframeMessage);
});

function initComplianceToggle() {
  const btn = document.getElementById('complianceToggleBtn');
  const panel = document.getElementById('compliancePanel');
  if (!btn || !panel) return;
  btn.addEventListener('click', () => {
    panel.hidden = !panel.hidden;
  });
}

// ── Preferences (Sprache / Niveau / Tiefe / Websuche merken) ──────────────
const PREFS_KEY = 'adcraft_prefs_v1';

function initPreferences() {
  // Restore
  let prefs = {};
  try { prefs = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}'); } catch {}
  if (prefs.lang) {
    const sel = document.getElementById('langSelect');
    if (sel && [...sel.options].some(o => o.value === prefs.lang)) sel.value = prefs.lang;
  }
  if (prefs.level) {
    const r = document.querySelector(`input[name="level"][value="${prefs.level}"]`);
    if (r) r.checked = true;
  }
  if (prefs.depth) {
    const r = document.querySelector(`input[name="depth"][value="${prefs.depth}"]`);
    if (r) r.checked = true;
  }
  if (typeof prefs.webSearch === 'boolean') {
    const t = document.getElementById('webSearchToggle');
    if (t) {
      t.checked = prefs.webSearch;
      // Banner refresh
      document.getElementById('webSearchBanner').style.display = prefs.webSearch ? '' : 'none';
      document.getElementById('noSourcesBanner').style.display = prefs.webSearch ? 'none' : '';
    }
  }
  // Save on change
  const save = () => {
    const p = {
      lang:      document.getElementById('langSelect')?.value,
      level:     document.querySelector('input[name="level"]:checked')?.value,
      depth:     document.querySelector('input[name="depth"]:checked')?.value,
      webSearch: document.getElementById('webSearchToggle')?.checked,
    };
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); } catch {}
  };
  document.getElementById('langSelect')?.addEventListener('change', save);
  document.querySelectorAll('input[name="level"]').forEach(r => r.addEventListener('change', save));
  document.querySelectorAll('input[name="depth"]').forEach(r => r.addEventListener('change', save));
  document.getElementById('webSearchToggle')?.addEventListener('change', save);
}

// ── Navigation ─────────────────────────────────────────────────────────────
function initNav() {
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => { e.preventDefault(); switchView(link.dataset.view); });
  });
}
function switchView(name) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  // Map: 'artifact' -> viewArtifact ; ältere Links 'learningPathViewer' werden gleichbehandelt
  const targetId = name === 'learningPathViewer' ? 'viewArtifact' : ('view' + name.charAt(0).toUpperCase() + name.slice(1));
  document.getElementById(targetId)?.classList.add('active');
  document.querySelector(`.nav-link[data-view="${name}"]`)?.classList.add('active');
  if (name === 'sources')      renderSourcesPage();
  if (name === 'prompts')      renderPromptsPage();
  if (name === 'library')      loadLibrary();
  if (name === 'certificates') loadCertificates();
}

// ── Provider badge ─────────────────────────────────────────────────────────
async function loadProvider() {
  try {
    const r = await fetch('/api/provider');
    if (!r.ok) return;
    const d = await r.json();
    document.getElementById('providerBadge').textContent = [d.name, d.model].filter(Boolean).join(' · ');
  } catch {}
}

// ── Formats ────────────────────────────────────────────────────────────────
async function loadFormats() {
  try {
    const r = await fetch('/api/formats');
    if (!r.ok) throw new Error(r.statusText);
    allFormats = await r.json();
    // Stat zeigt nur die aktiven Formate
    const activeCount = allFormats.filter(f => !f.comingSoon).length;
    document.getElementById('statFormats').textContent = activeCount;

    const sel = document.getElementById('formatSelect');
    sel.innerHTML = '<option value="">– Format wählen –</option>';
    allFormats.forEach(f => {
      const o = document.createElement('option');
      o.value = f.id;
      o.textContent = f.label + (f.comingSoon ? '  · in Kürze' : '');
      o.disabled = !!f.comingSoon;
      sel.appendChild(o);
    });
    sel.addEventListener('change', () => {
      const f = allFormats.find(x => x.id === sel.value);
      document.getElementById('formatHint').textContent = f?.description || '';
    });

    const grid = document.getElementById('formatGrid');
    grid.innerHTML = '';
    allFormats.forEach(f => {
      const card = document.createElement('div');
      card.className = 'format-card' + (f.comingSoon ? ' format-card-soon' : '');
      card.innerHTML = `
        ${f.comingSoon ? '<span class="coming-soon-badge">in Kürze verfügbar</span>' : ''}
        <div class="format-card-label">${esc(f.label)}</div>
        <div class="format-card-desc">${esc(f.description)}</div>`;
      if (!f.comingSoon) {
        card.addEventListener('click', () => {
          switchView('generator');
          document.getElementById('formatSelect').value = f.id;
          document.getElementById('formatHint').textContent = f.description;
        });
      }
      grid.appendChild(card);
    });

    populateLibraryFilter();
  } catch (err) { console.error('[formats]', err); }
}

// ── Websuche Toggle ────────────────────────────────────────────────────────
function initWebSearchToggle() {
  const toggle = document.getElementById('webSearchToggle');
  if (!toggle) return;
  toggle.addEventListener('change', () => {
    const on = toggle.checked;
    document.getElementById('webSearchBanner').style.display = on ? '' : 'none';
    document.getElementById('noSourcesBanner').style.display = on ? 'none' : '';
  });
}
function isWebSearchOn() { return document.getElementById('webSearchToggle')?.checked ?? true; }

// ── Sources laden ──────────────────────────────────────────────────────────
async function loadSources() {
  try {
    const r = await fetch('/api/sources');
    if (!r.ok) return;
    sources = await r.json();
    renderSourceList();
    updateSourceStats();
  } catch {}
}
function updateSourceStats() {
  document.getElementById('statSources').textContent = sources.length;
  const lbl = document.getElementById('sourcesCountLabel');
  if (lbl) lbl.textContent = `${sources.length} Quelle${sources.length !== 1 ? 'n' : ''}`;
  const clearBtn = document.getElementById('clearAllSourcesBtn');
  if (clearBtn) clearBtn.style.display = sources.length > 0 ? '' : 'none';
}

function renderSourceList() {
  const list = document.getElementById('sourceList');
  if (!list) return;
  if (sources.length === 0) {
    list.innerHTML = '<div class="source-empty-hint">Noch keine Quellen. Füge Text, Dateien oder URLs hinzu.</div>';
    return;
  }
  list.innerHTML = '';
  sources.forEach(s => {
    const checked = selectedSrcs.has(s.id);
    const item = document.createElement('div');
    item.className = 'source-item' + (checked ? ' selected' : '');
    item.innerHTML = `
      <label class="source-item-check">
        <input type="checkbox" data-id="${esc(s.id)}" ${checked ? 'checked' : ''}>
        <span class="source-item-icon">${sourceIcon(s.type)}</span>
        <span class="source-item-name">${esc(s.name)}</span>
        ${s.size ? `<span class="source-item-size">${formatBytes(s.size)}</span>` : ''}
      </label>
      <button class="source-item-del" data-id="${esc(s.id)}" title="Entfernen">✕</button>`;
    item.querySelector('input[type=checkbox]').addEventListener('change', e => {
      e.target.checked ? selectedSrcs.add(s.id) : selectedSrcs.delete(s.id);
      item.classList.toggle('selected', e.target.checked);
    });
    item.querySelector('.source-item-del').addEventListener('click', () => deleteSource(s.id));
    list.appendChild(item);
  });
}
function sourceIcon(type) {
  return { pdf:'📄', image:'🖼️', url:'🌐', text:'📝' }[type] || '📎';
}
async function deleteSource(id) {
  await fetch(`/api/sources/${id}`, { method: 'DELETE' });
  sources = sources.filter(s => s.id !== id);
  selectedSrcs.delete(id);
  renderSourceList(); renderSourcesPage(); updateSourceStats();
}

// ── Source-Tabs ────────────────────────────────────────────────────────────
function initSourceTabs() {
  document.querySelectorAll('.source-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.source-add-box, .sources-toolbar');
      group?.querySelectorAll('.source-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const paneId = btn.dataset.tab;
      group?.querySelectorAll('.source-pane').forEach(p => p.classList.remove('active'));
      group?.querySelector('#' + paneId)?.classList.add('active');
    });
  });
}

function initSourceActions() {
  document.getElementById('addTextBtn')?.addEventListener('click', async () => {
    const content = document.getElementById('sourceText').value.trim();
    const name    = document.getElementById('sourceTextName').value.trim() || 'Text-Quelle';
    if (!content) return alert('Bitte Text eingeben.');
    await addTextSource(content, name);
    document.getElementById('sourceText').value = '';
    document.getElementById('sourceTextName').value = '';
  });

  const dropZone  = document.getElementById('fileDropZone');
  const fileInput = document.getElementById('fileInput');
  if (dropZone) {
    dropZone.addEventListener('click', () => fileInput.click());
    dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
    dropZone.addEventListener('drop', e => { e.preventDefault(); dropZone.classList.remove('drag-over'); if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0], 'fileStatus'); });
    fileInput.addEventListener('change', () => { if (fileInput.files[0]) uploadFile(fileInput.files[0], 'fileStatus'); });
  }

  document.getElementById('addUrlBtn')?.addEventListener('click', async () => {
    const url = document.getElementById('sourceUrl').value.trim();
    if (!url) return alert('Bitte URL eingeben.');
    await addUrlSource(url, 'urlStatus');
    document.getElementById('sourceUrl').value = '';
  });

  document.getElementById('clearAllSourcesBtn')?.addEventListener('click', async () => {
    if (!confirm('Alle Quellen entfernen?')) return;
    await Promise.all(sources.map(s => fetch(`/api/sources/${s.id}`, { method: 'DELETE' })));
    sources = []; selectedSrcs.clear();
    renderSourceList(); renderSourcesPage(); updateSourceStats();
  });
}

function initSvSourceActions() {
  document.getElementById('svAddTextBtn')?.addEventListener('click', async () => {
    const content = document.getElementById('svText').value.trim();
    const name    = document.getElementById('svTextName').value.trim() || 'Text-Quelle';
    if (!content) return alert('Bitte Text eingeben.');
    await addTextSource(content, name);
    document.getElementById('svText').value = '';
    document.getElementById('svTextName').value = '';
    renderSourcesPage();
  });

  const svDrop  = document.getElementById('svFileDropZone');
  const svInput = document.getElementById('svFileInput');
  if (svDrop) {
    svDrop.addEventListener('click', () => svInput.click());
    svDrop.addEventListener('dragover',  e => { e.preventDefault(); svDrop.classList.add('drag-over'); });
    svDrop.addEventListener('dragleave', () => svDrop.classList.remove('drag-over'));
    svDrop.addEventListener('drop', e => { e.preventDefault(); svDrop.classList.remove('drag-over'); if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0], 'svFileStatus', true); });
    svInput.addEventListener('change', () => { if (svInput.files[0]) uploadFile(svInput.files[0], 'svFileStatus', true); });
  }

  document.getElementById('svAddUrlBtn')?.addEventListener('click', async () => {
    const url = document.getElementById('svUrl').value.trim();
    if (!url) return alert('Bitte URL eingeben.');
    await addUrlSource(url, 'svUrlStatus', true);
    document.getElementById('svUrl').value = '';
  });
}

function renderSourcesPage() {
  const grid = document.getElementById('sourcesGrid');
  if (!grid) return;
  if (sources.length === 0) {
    grid.innerHTML = '<div class="sources-empty"><span>📚</span><p>Noch keine Quellen geladen.</p></div>';
    return;
  }
  grid.innerHTML = '';
  sources.forEach(s => {
    const checked = selectedSrcs.has(s.id);
    const card = document.createElement('div');
    card.className = 'source-card' + (checked ? ' source-card-selected' : '');
    card.innerHTML = `
      <div class="source-card-header">
        <span class="source-card-icon">${sourceIcon(s.type)}</span>
        <span class="source-card-type">${capitalize(s.type)}</span>
        <button class="source-card-del" data-id="${esc(s.id)}">✕</button>
      </div>
      <div class="source-card-name">${esc(s.name)}</div>
      ${s.preview ? `<div class="source-card-preview">${esc(s.preview)}</div>` : ''}
      ${s.size    ? `<div class="source-card-size">${formatBytes(s.size)}</div>` : ''}
      <label class="source-card-select">
        <input type="checkbox" data-id="${esc(s.id)}" ${checked ? 'checked' : ''}> Für Generierung auswählen
      </label>`;
    card.querySelector('.source-card-del').addEventListener('click', () => deleteSource(s.id));
    card.querySelector('input[type=checkbox]').addEventListener('change', e => {
      e.target.checked ? selectedSrcs.add(s.id) : selectedSrcs.delete(s.id);
      card.classList.toggle('source-card-selected', e.target.checked);
      renderSourceList();
    });
    grid.appendChild(card);
  });
}

// ── Prompts-Seite ─────────────────────────────────────────────────────────
async function renderPromptsPage() {
  const grid = document.getElementById('promptsGrid');
  if (!grid || allFormats.length === 0) return;
  grid.innerHTML = '';

  // Versionen für jedes Format laden, damit wir Aktiv-Badges anzeigen können.
  const versionMap = {};
  await Promise.all(allFormats.map(async f => {
    try {
      const r = await fetch(`/api/prompt-versions/${encodeURIComponent(f.id)}`);
      if (r.ok) versionMap[f.id] = await r.json();
    } catch {}
  }));

  allFormats.forEach(f => {
    const v = versionMap[f.id];
    const isDefault = !v || v.activeId === 'default';
    const activeName = isDefault
      ? 'Standard'
      : (v.versions.find(x => x.id === v.activeId)?.name || 'Custom');
    const customCount = v ? v.versions.filter(x => !x.isDefault).length : 0;

    const card = document.createElement('div');
    card.className = 'prompt-card';
    card.innerHTML = `
      <div class="prompt-card-active-badge ${isDefault ? 'is-default' : ''}">
        ${isDefault ? '★ Standard' : '★ ' + esc(activeName)}
      </div>
      <div class="prompt-card-label">${esc(f.label)}</div>
      <p class="prompt-card-desc">${esc(f.description)}</p>
      <div class="prompt-card-meta">
        ${customCount > 0 ? customCount + ' eigene Version' + (customCount !== 1 ? 'en' : '') + ' · ' : ''}Klicken zum Anzeigen / Bearbeiten →
      </div>`;
    card.addEventListener('click', () => openPromptEditor(f));
    grid.appendChild(card);
  });
}

// ── Prompt-Editor Modal ───────────────────────────────────────────────────
function initPromptEditorModal() {
  const modal = document.getElementById('promptEditorModal');
  if (!modal) return;
  modal.addEventListener('click', e => {
    if (e.target.matches('[data-close-modal]')) closePromptEditor();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && modal.classList.contains('open')) closePromptEditor();
  });

  document.getElementById('peVersionSelect').addEventListener('change', e => {
    if (peState.dirty && !confirm('Ungespeicherte Änderungen verwerfen?')) {
      e.target.value = peState.selected;
      return;
    }
    peState.selected = e.target.value;
    peState.dirty = false;
    renderPromptEditorBody();
  });

  document.getElementById('peNewBtn').addEventListener('click', onCreateNewVersion);
  document.getElementById('peDeleteBtn').addEventListener('click', onDeleteVersion);
  document.getElementById('peRenameBtn').addEventListener('click', onRenameVersion);
  document.getElementById('peSetActiveBtn').addEventListener('click', onSetActive);
  document.getElementById('peSaveBtn').addEventListener('click', onSavePrompt);

  ['peSystemPrompt', 'peUserPrompt'].forEach(id => {
    document.getElementById(id).addEventListener('input', () => {
      if (peState.selected === 'default') return;  // Default ist readonly
      peState.dirty = true;
      setPeStatus('Ungespeicherte Änderungen…', 'info');
    });
  });
}

async function openPromptEditor(format) {
  peState.formatId = format.id;
  peState.dirty = false;
  document.getElementById('promptEditorTitle').textContent = 'Prompt: ' + format.label;
  setPeStatus('', '');
  document.getElementById('promptEditorModal').classList.add('open');
  await loadPromptVersions();
}

function closePromptEditor() {
  if (peState.dirty && !confirm('Ungespeicherte Änderungen verwerfen?')) return;
  document.getElementById('promptEditorModal').classList.remove('open');
  peState = { formatId: null, data: null, selected: null, dirty: false };
  // Nach dem Schließen die Karten aktualisieren (Aktiv-Badge könnte gewechselt haben)
  renderPromptsPage();
}

async function loadPromptVersions() {
  try {
    const r = await fetch(`/api/prompt-versions/${encodeURIComponent(peState.formatId)}`);
    if (!r.ok) throw new Error(r.statusText);
    peState.data = await r.json();
    peState.selected = peState.data.activeId || 'default';
    renderVersionSelect();
    renderPromptEditorBody();
  } catch (err) {
    setPeStatus('Fehler beim Laden: ' + err.message, 'error');
  }
}

function renderVersionSelect() {
  const sel = document.getElementById('peVersionSelect');
  if (!sel || !peState.data) return;
  sel.innerHTML = '';
  peState.data.versions.forEach(v => {
    const opt = document.createElement('option');
    opt.value = v.id;
    const isActive = v.id === peState.data.activeId;
    opt.textContent = v.name + (v.isDefault ? ' (Standard)' : '') + (isActive ? '  ★' : '');
    sel.appendChild(opt);
  });
  sel.value = peState.selected;
}

function renderPromptEditorBody() {
  if (!peState.data) return;
  const v = peState.data.versions.find(x => x.id === peState.selected) || peState.data.versions[0];
  const isDefault = v.isDefault;
  const isActive  = v.id === peState.data.activeId;

  document.getElementById('peSystemPrompt').value = v.systemPrompt || '';
  document.getElementById('peUserPrompt').value   = v.userPrompt   || '';
  document.getElementById('peSystemPrompt').readOnly = isDefault;
  document.getElementById('peUserPrompt').readOnly   = isDefault;

  document.getElementById('peSaveBtn').disabled    = isDefault;
  document.getElementById('peDeleteBtn').disabled  = isDefault;
  document.getElementById('peRenameBtn').disabled  = isDefault;
  document.getElementById('peSetActiveBtn').disabled = isActive;

  const info = document.getElementById('peVersionInfo');
  if (isDefault) {
    info.innerHTML = '<strong>Standard-Version</strong> — kann nicht geändert oder gelöscht werden. Erstelle eine neue Version, um eigene Anpassungen zu speichern.';
  } else {
    info.textContent = `Eigene Version · zuletzt aktualisiert ${formatDate(v.updatedAt)}`;
  }

  // Status nur zurücksetzen, wenn nicht gerade "Ungespeichert" angezeigt wird
  if (!peState.dirty) setPeStatus(isActive ? '✓ Diese Version ist aktiv und wird beim Generieren verwendet.' : '', isActive ? 'success' : '');
}

async function onCreateNewVersion() {
  const baseName = peState.data.versions.find(v => v.id === peState.selected)?.name || 'Standard';
  const name = prompt('Name der neuen Version:', `Kopie von ${baseName}`);
  if (!name) return;
  const baseSys  = document.getElementById('peSystemPrompt').value;
  const baseUser = document.getElementById('peUserPrompt').value;

  try {
    const r = await fetch(`/api/prompt-versions/${encodeURIComponent(peState.formatId)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, systemPrompt: baseSys, userPrompt: baseUser }),
    });
    if (!r.ok) throw new Error((await r.json()).error || r.statusText);
    const created = await r.json();
    await loadPromptVersions();
    peState.selected = created.id;
    peState.dirty = false;
    renderVersionSelect();
    renderPromptEditorBody();
    setPeStatus(`✓ Version "${created.name}" angelegt.`, 'success');
  } catch (err) {
    setPeStatus('Fehler: ' + err.message, 'error');
  }
}

async function onDeleteVersion() {
  const v = peState.data.versions.find(x => x.id === peState.selected);
  if (!v || v.isDefault) return;
  if (!confirm(`Version "${v.name}" wirklich löschen?`)) return;
  try {
    const r = await fetch(`/api/prompt-versions/${encodeURIComponent(peState.formatId)}/${encodeURIComponent(v.id)}`, { method: 'DELETE' });
    if (!r.ok) throw new Error((await r.json()).error || r.statusText);
    await loadPromptVersions();
    setPeStatus('✓ Version gelöscht.', 'success');
  } catch (err) {
    setPeStatus('Fehler: ' + err.message, 'error');
  }
}

async function onRenameVersion() {
  const v = peState.data.versions.find(x => x.id === peState.selected);
  if (!v || v.isDefault) return;
  const name = prompt('Neuer Name:', v.name);
  if (!name || name === v.name) return;
  try {
    const r = await fetch(`/api/prompt-versions/${encodeURIComponent(peState.formatId)}/${encodeURIComponent(v.id)}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    });
    if (!r.ok) throw new Error((await r.json()).error || r.statusText);
    await loadPromptVersions();
    setPeStatus('✓ Umbenannt.', 'success');
  } catch (err) {
    setPeStatus('Fehler: ' + err.message, 'error');
  }
}

async function onSetActive() {
  try {
    const r = await fetch(`/api/prompt-versions/${encodeURIComponent(peState.formatId)}/active`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ versionId: peState.selected }),
    });
    if (!r.ok) throw new Error((await r.json()).error || r.statusText);
    await loadPromptVersions();
    setPeStatus('✓ Diese Version ist jetzt aktiv und wird beim Generieren verwendet.', 'success');
  } catch (err) {
    setPeStatus('Fehler: ' + err.message, 'error');
  }
}

async function onSavePrompt() {
  const v = peState.data.versions.find(x => x.id === peState.selected);
  if (!v || v.isDefault) return;
  const systemPrompt = document.getElementById('peSystemPrompt').value;
  const userPrompt   = document.getElementById('peUserPrompt').value;
  try {
    const r = await fetch(`/api/prompt-versions/${encodeURIComponent(peState.formatId)}/${encodeURIComponent(v.id)}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ systemPrompt, userPrompt }),
    });
    if (!r.ok) throw new Error((await r.json()).error || r.statusText);
    peState.dirty = false;
    await loadPromptVersions();
    setPeStatus('✓ Gespeichert.', 'success');
  } catch (err) {
    setPeStatus('Fehler: ' + err.message, 'error');
  }
}

function setPeStatus(text, kind) {
  const el = document.getElementById('peStatus');
  if (!el) return;
  el.textContent = text;
  el.className = 'pe-status' + (kind ? ' ' + kind : '');
}

// ── Generate ───────────────────────────────────────────────────────────────
function initGenerate() {
  document.getElementById('generateBtn')?.addEventListener('click', handleGenerate);
}

async function handleGenerate() {
  const topic    = document.getElementById('topicInput')?.value.trim();
  const formatId = document.getElementById('formatSelect')?.value;
  if (!topic)    { alert('Bitte ein Thema eingeben.'); return; }
  if (!formatId) { alert('Bitte ein Format wählen.'); return; }

  const webSearch = isWebSearchOn();
  if (!webSearch && selectedSrcs.size === 0) {
    alert('Websuche ist deaktiviert — bitte mindestens eine Quelle auswählen.');
    return;
  }

  currentLibraryId = null;
  const btn = document.getElementById('generateBtn');
  btn.disabled = true;
  const artifactBtns = document.getElementById('artifactBtns');
  const tokenCounter  = document.getElementById('tokenCounter');
  artifactBtns.innerHTML = ''; artifactBtns.style.display = 'none';
  tokenCounter.textContent = ''; tokenCounter.style.display = 'none';
  const genRating = document.getElementById('generatorRating');
  if (genRating) { genRating.style.display = 'none'; genRating.innerHTML = ''; }

  showLoadingState('prepare', 'Anfrage vorbereiten …', 8);
  const t1 = setTimeout(() => showLoadingState('llm', 'KI generiert Inhalt …', 18), 700);
  let pct = 18;
  const ticker = setInterval(() => {
    pct = Math.min(pct + Math.random() * 2.5, 72);
    showLoadingState('llm', 'KI generiert Inhalt …', Math.round(pct));
  }, 2000);

  const language = document.getElementById('langSelect')?.value || 'de';
  const level    = document.querySelector('input[name="level"]:checked')?.value || 'intermediate';
  const depth    = document.querySelector('input[name="depth"]:checked')?.value || 'standard';
  const audience = document.getElementById('audienceInput')?.value.trim() || '';
  const classification = document.getElementById('classificationSelect')?.value || 'internal';
  const validityDays   = document.getElementById('validityInput')?.value || '';
  const validUntil = validityDays
    ? new Date(Date.now() + Number(validityDays) * 86400000).toISOString()
    : null;

  try {
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ formatId, topic, sourceIds: [...selectedSrcs], webSearch, language, level, depth, audience }),
    });

    clearTimeout(t1); clearInterval(ticker);
    if (!res.ok) { const err = await res.json().catch(() => ({ error: res.statusText })); throw new Error(err.error || res.statusText); }

    showLoadingState('render', 'Ausgabe aufbereiten …', 88);
    const data = await res.json();
    generationCount++;
    document.getElementById('statGenerated').textContent = generationCount;
    renderOutput(data);

    const libId = await autoSaveToLibrary(data, {
      topic, formatId, language, level, depth, audience,
      classification, validUntil,
      sources: data.sourceSnapshot || [],
      webSearchUsed: data.webSearchUsed,
    });
    currentLibraryId = libId;

    // Bewertungs-Widget einblenden (sobald Library-ID feststeht)
    if (libId && genRating) {
      const item = libraryItems.find(x => x.id === libId);
      if (item) {
        genRating.style.display = '';
        renderRatingInto(genRating, item);
      }
    }

    if (data.usage) {
      const u = data.usage;
      tokenCounter.textContent = `↑ ${u.input_tokens ?? u.prompt_tokens ?? '?'} · ↓ ${u.output_tokens ?? u.completion_tokens ?? '?'} Tokens`;
      tokenCounter.style.display = '';
    }
    if (data.artifacts?.length || data.output) {
      artifactBtns.style.display = '';
      const pseudoItem = {
        title:     topic,
        topic:     topic,
        formatId:  formatId,
        output:    data.output || '',
        artifacts: data.artifacts || [],
      };
      renderDownloadMenu(artifactBtns, pseudoItem, formatId);
    }

    if (formatId === 'learningpath' && libId) {
      setTimeout(() => {
        document.querySelector('.output-iframe')?.contentWindow
          ?.postMessage({ type: 'SET_LIBRARY_ID', libraryId: libId }, '*');
      }, 600);
    }

  } catch (err) {
    clearTimeout(t1); clearInterval(ticker);
    document.getElementById('previewContent').innerHTML =
      `<div class="error-state"><strong>Fehler:</strong> ${esc(err.message)}</div>`;
  } finally {
    btn.disabled = false;
  }
}

function renderOutput(data) {
  const preview = document.getElementById('previewContent');
  if (!preview) return;
  // Quick-Sheet: gerendertes HTML-Artefakt im iframe zeigen (PDF-Look)
  if (data.formatId === 'quick_sheet') {
    const htmlArtifact = data.artifacts?.find(a => a.kind === 'html');
    if (htmlArtifact) {
      preview.innerHTML = `<div class="qs-output-wrap"><iframe src="${htmlArtifact.url}" class="qs-output-frame" frameborder="0"></iframe></div>`;
      return;
    }
  }
  if (data.formatId === 'flashcards' || data.formatId === 'learningpath') {
    const htmlArtifact = data.artifacts?.find(a => a.kind === 'html');
    if (htmlArtifact) {
      preview.innerHTML = `<iframe src="${htmlArtifact.url}" class="output-iframe" frameborder="0"></iframe>`;
      return;
    }
    // HTML-Renderer ist serverseitig fehlgeschlagen (meist: ungültige JSON-Struktur)
    preview.innerHTML = `
      <div class="error-state">
        <strong>Interaktive Vorschau konnte nicht erzeugt werden.</strong>
        Das Modell hat zwar geantwortet, aber das Ergebnis war keine gültige JSON-Struktur für ${data.formatId === 'learningpath' ? 'einen Lernpfad' : 'Karteikarten'}.
        Du kannst den Roh-Output unten als JSON herunterladen und manuell prüfen — oder einfach erneut generieren.
      </div>
      <details style="margin: 0 24px 24px; padding: 14px 16px; border: 1px solid var(--gray-150); border-radius: 8px; background: var(--gray-50);">
        <summary style="cursor: pointer; font-weight: 600; font-size: .85rem; color: var(--gray-700);">Roh-Output anzeigen</summary>
        <pre style="margin-top: 12px; font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: .78rem; line-height: 1.5; white-space: pre-wrap; max-height: 400px; overflow: auto; color: var(--gray-700);">${esc(data.output || '')}</pre>
      </details>`;
    return;
  }
  if (data.formatId === 'pptx_deck') {
    preview.innerHTML = `<div style="height:100%;overflow:auto">${renderPptxPreview({ title: '', output: data.output, formatId: 'pptx_deck' })}</div>`;
    return;
  }
  preview.innerHTML = `<div class="markdown-body" style="padding:20px 24px">${markdownToHtml(data.output || '')}</div>`;
}

// ── Loading ────────────────────────────────────────────────────────────────
function showLoadingState(phase, label, pct) {
  const preview = document.getElementById('previewContent');
  if (!preview) return;
  preview.innerHTML = `
    <div class="loading-state">
      <div class="loading-spinner"></div>
      <div class="loading-label">${esc(label)}</div>
      <div class="loading-bar-wrap"><div class="loading-bar" style="width:${pct}%"></div></div>
      <div class="loading-pct">${pct}%</div>
    </div>`;
}

// ── Library ────────────────────────────────────────────────────────────────
async function loadLibrary() {
  try {
    const r = await fetch('/api/library');
    if (!r.ok) return;
    libraryItems = await r.json();
    renderLibraryGrid();
    renderRecentOnDashboard();
    updateLibraryStat();
    populateLibraryFilter();
  } catch {}
}

function updateLibraryStat() {
  const el = document.getElementById('statLibrary');
  if (el) el.textContent = libraryItems.length;
}

function populateLibraryFilter() {
  const sel = document.getElementById('libraryFilter');
  if (!sel || allFormats.length === 0) return;
  const usedFormats = [...new Set(libraryItems.map(i => i.formatId))];
  sel.innerHTML = '<option value="">Alle Formate</option>';
  usedFormats.forEach(f => {
    const label = allFormats.find(x => x.id === f)?.label || f;
    sel.innerHTML += `<option value="${esc(f)}">${esc(label)}</option>`;
  });
}

function initLibraryEvents() {
  const refresh = () => renderLibraryGrid(
    document.getElementById('libraryFilter')?.value || '',
    document.getElementById('librarySearch')?.value || '',
    document.getElementById('librarySort')?.value || 'newest'
  );
  document.getElementById('librarySearch')?.addEventListener('input', refresh);
  document.getElementById('libraryFilter')?.addEventListener('change', refresh);
  document.getElementById('librarySort')?.addEventListener('change', refresh);
}

function sortItems(items, mode) {
  const arr = items.slice();
  switch (mode) {
    case 'oldest': return arr.sort((a, b) => new Date(a.savedAt) - new Date(b.savedAt));
    case 'rating': return arr.sort((a, b) => (b.rating || 0) - (a.rating || 0) || new Date(b.savedAt) - new Date(a.savedAt));
    case 'title':  return arr.sort((a, b) => (a.title || '').localeCompare(b.title || '', 'de'));
    case 'format': return arr.sort((a, b) => (a.formatId || '').localeCompare(b.formatId || '') || new Date(b.savedAt) - new Date(a.savedAt));
    case 'newest':
    default:       return arr.sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));
  }
}

function renderLibraryGrid(filter = '', search = '', sort = 'newest') {
  const grid = document.getElementById('libraryGrid');
  if (!grid) return;
  let items = libraryItems;
  if (filter) items = items.filter(i => i.formatId === filter);
  if (search) items = items.filter(i =>
    (i.title || '').toLowerCase().includes(search.toLowerCase()) ||
    (i.topic || '').toLowerCase().includes(search.toLowerCase())
  );
  items = sortItems(items, sort);

  // Trefferzahl
  const counter = document.getElementById('resultsCount');
  if (counter) {
    counter.textContent = items.length === libraryItems.length
      ? `${items.length} Eintr${items.length === 1 ? 'ag' : 'äge'}`
      : `${items.length} von ${libraryItems.length}`;
  }

  if (items.length === 0) {
    grid.innerHTML = '<div class="sources-empty"><span>📭</span><p>Keine Einträge gefunden.</p></div>';
    return;
  }
  grid.innerHTML = '';
  items.forEach(item => buildLibraryCard(item, grid));
}

function buildLibraryCard(item, container) {
  const isLP     = item.formatId === 'learningpath';
  const prog     = item.progress;
  const pct      = isLP && prog ? Math.round((prog.doneCount / Math.max(prog.totalPages, 1)) * 100) : null;
  const fmtLabel = allFormats.find(f => f.id === item.formatId)?.label || item.formatId;
  const rating   = item.rating || 0;

  // Validity: ok / warn (< 14 days remaining) / expired
  const validityStatus = computeValidityStatus(item.validUntil);

  const card = document.createElement('div');
  card.className = 'lib-card' +
    (validityStatus === 'expired' ? ' expired' :
     validityStatus === 'warn'    ? ' expiring' : '');

  card.innerHTML = `
    <div class="lib-card-header">
      <span class="lib-card-format">${esc(fmtLabel)}</span>
      <span class="lib-card-date">${formatDate(item.savedAt)}</span>
      <button class="lib-del-btn" data-id="${esc(item.id)}" title="Löschen">✕</button>
    </div>
    <div class="lib-card-title">${esc(item.title)}</div>
    ${item.topic ? `<div class="lib-card-topic">Thema: ${esc(item.topic)}</div>` : ''}
    <div class="badge-row">
      ${item.classification ? renderClassificationBadge(item.classification) : ''}
      ${validityStatus !== 'none' ? renderValidityBadge(validityStatus, item.validUntil) : ''}
    </div>
    ${rating > 0 ? `<div class="lib-card-rating">${renderStarsReadonly(rating)}</div>` : ''}
    ${pct !== null ? `
      <div class="lib-progress-wrap"><div class="lib-progress-bar" style="width:${pct}%"></div></div>
      <div class="lib-progress-label">${pct}% · ${prog.doneCount} / ${prog.totalPages} Schritte</div>
    ` : ''}
    <div class="lib-card-actions">
      <button class="btn btn-primary btn-sm lib-action-btn" data-id="${esc(item.id)}">
        ${isLP && pct !== null && pct > 0 && pct < 100 ? '▶ Weitermachen' : '▶ Öffnen'}
      </button>
      <button class="lib-card-clone-btn" title="Mit gleichen Einstellungen neu generieren">⟲ Erneut</button>
    </div>`;

  card.querySelector('.lib-del-btn').addEventListener('click', e => {
    e.stopPropagation();
    deleteLibraryItem(item.id);
  });
  card.querySelector('.lib-action-btn')?.addEventListener('click', e => {
    e.stopPropagation();
    openLibraryItem(item.id);
  });
  card.querySelector('.lib-card-clone-btn')?.addEventListener('click', e => {
    e.stopPropagation();
    regenerateFromItem(item);
  });
  card.addEventListener('click', e => {
    if (e.target.closest('button, a')) return;
    openLibraryItem(item.id);
  });
  card.style.cursor = 'pointer';
  container.appendChild(card);
}

// ── Helpers für Klassifizierung & Validität ───────────────────────────────
const CLASSIFICATION_LABELS = {
  public:        { icon: '🌍', label: 'Öffentlich' },
  internal:      { icon: '🏢', label: 'Intern' },
  confidential:  { icon: '🔒', label: 'Vertraulich' },
  customer:      { icon: '👥', label: 'Kundenspezifisch' },
};

function renderClassificationBadge(cls) {
  const c = CLASSIFICATION_LABELS[cls] || CLASSIFICATION_LABELS.internal;
  return `<span class="cls-badge cls-${esc(cls)}" title="Datenklassifizierung">${c.icon} ${c.label}</span>`;
}

function computeValidityStatus(validUntil) {
  if (!validUntil) return 'none';
  const now = Date.now();
  const due = new Date(validUntil).getTime();
  if (isNaN(due)) return 'none';
  const daysLeft = Math.ceil((due - now) / 86400000);
  if (daysLeft < 0)  return 'expired';
  if (daysLeft <= 14) return 'warn';
  return 'ok';
}

function renderValidityBadge(status, validUntil) {
  const date = validUntil ? new Date(validUntil) : null;
  const dateStr = date ? date.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '';
  if (status === 'expired') return `<span class="validity-badge valid-expired" title="Abgelaufen">⚠ Abgelaufen</span>`;
  if (status === 'warn')    return `<span class="validity-badge valid-warn" title="Läuft bald ab">⏰ bis ${dateStr}</span>`;
  if (status === 'ok')      return `<span class="validity-badge valid-ok" title="Gültig">✓ bis ${dateStr}</span>`;
  return '';
}

function regenerateFromItem(item) {
  switchView('generator');
  document.getElementById('topicInput').value   = item.topic || item.title || '';
  document.getElementById('formatSelect').value = item.formatId || '';
  document.getElementById('formatHint').textContent =
    allFormats.find(f => f.id === item.formatId)?.description || '';
  if (item.language) document.getElementById('langSelect').value = item.language;
  if (item.level) {
    const lv = document.querySelector(`input[name="level"][value="${item.level}"]`);
    if (lv) lv.checked = true;
  }
  if (item.depth) {
    const dp = document.querySelector(`input[name="depth"][value="${item.depth}"]`);
    if (dp) dp.checked = true;
  }
  if (item.audience) document.getElementById('audienceInput').value = item.audience;
  if (item.classification) {
    const cls = document.getElementById('classificationSelect');
    if (cls) cls.value = item.classification;
  }
  // Scrolle nach oben + Hinweis
  setTimeout(() => {
    document.getElementById('topicInput')?.focus();
  }, 50);
}

function renderStarsReadonly(rating) {
  let h = '';
  for (let i = 1; i <= 5; i++) {
    h += `<span class="rating-star ${i <= rating ? 'filled' : ''}">★</span>`;
  }
  return h;
}

function renderRecentOnDashboard() {
  const section = document.getElementById('recentSection');
  const grid    = document.getElementById('recentGrid');
  if (!section || !grid) return;
  const recent = libraryItems.slice(0, 4);
  if (recent.length === 0) { section.style.display = 'none'; return; }
  section.style.display = '';
  grid.innerHTML = '';
  recent.forEach(item => buildLibraryCard(item, grid));
  renderTopRatedOnDashboard();
}

function renderTopRatedOnDashboard() {
  const section = document.getElementById('topRatedSection');
  const grid    = document.getElementById('topRatedGrid');
  if (!section || !grid) return;
  const top = libraryItems
    .filter(i => (i.rating || 0) >= 4)
    .sort((a, b) => (b.rating || 0) - (a.rating || 0) || new Date(b.savedAt) - new Date(a.savedAt))
    .slice(0, 6);
  if (top.length === 0) { section.style.display = 'none'; return; }
  section.style.display = '';
  grid.innerHTML = '';
  top.forEach(item => {
    const fmtLabel = allFormats.find(f => f.id === item.formatId)?.label || item.formatId;
    const pill = document.createElement('button');
    pill.className = 'top-rated-pill';
    pill.innerHTML = `
      <span class="pill-stars">${'★'.repeat(item.rating || 0)}</span>
      <span class="pill-title">${esc(item.title)}</span>
      <span class="pill-format">${esc(fmtLabel.split(' ')[0])}</span>`;
    pill.addEventListener('click', () => openLibraryItem(item.id));
    grid.appendChild(pill);
  });
}

async function autoSaveToLibrary(data, meta) {
  try {
    const entry = {
      title:     meta.topic || 'Unbenannt',
      topic:     meta.topic,
      formatId:  meta.formatId,
      language:  meta.language,
      level:     meta.level,
      depth:     meta.depth,
      audience:  meta.audience,
      classification: meta.classification || 'internal',
      validUntil:     meta.validUntil || null,
      sources:        meta.sources || [],
      webSearchUsed:  meta.webSearchUsed !== false,
      output:    data.output || '',
      artifacts: (data.artifacts || []).map(a => ({ url: a.url, filename: a.filename, kind: a.kind })),
      progress:  null,
      rating:    0,
      feedback:  '',
    };
    const saved = await fetch('/api/library', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(entry),
    }).then(r => r.json());
    libraryItems.unshift(saved);
    updateLibraryStat();
    return saved.id;
  } catch (err) { console.error('[library auto-save]', err); return null; }
}

async function deleteLibraryItem(id) {
  if (!confirm('Eintrag löschen?')) return;
  await fetch(`/api/library/${id}`, { method: 'DELETE' });
  libraryItems = libraryItems.filter(i => i.id !== id);
  renderLibraryGrid();
  renderRecentOnDashboard();
  updateLibraryStat();
}

// ── Library-Item öffnen — IMMER im separaten Viewer ──────────────────────
async function openLibraryItem(id) {
  const item = libraryItems.find(i => i.id === id)
    || await fetch(`/api/library/${id}`).then(r => r.json()).catch(() => null);
  if (!item) return;
  openArtifactViewer(item);
}

function openArtifactViewer(item) {
  currentArtifactItem = item;
  currentLibraryId = item.id;

  switchView('artifact');
  const titleEl = document.getElementById('artifactViewerTitle');
  const fmtLabel = allFormats.find(f => f.id === item.formatId)?.label || item.formatId;
  if (titleEl) titleEl.textContent = `${item.title}  ·  ${fmtLabel}`;

  // Badges (Klassifizierung + Validität) in der Topbar
  const badgeRow = document.getElementById('artifactBadges');
  if (badgeRow) {
    const validity = computeValidityStatus(item.validUntil);
    badgeRow.innerHTML =
      (item.classification ? renderClassificationBadge(item.classification) : '') +
      (validity !== 'none' ? renderValidityBadge(validity, item.validUntil) : '');
  }

  // Compliance-Panel (eingeklappt by default)
  const cp = document.getElementById('compliancePanel');
  if (cp) cp.hidden = true;
  populateCompliancePanel(item);

  // Rating UI
  const ratingWrap = document.getElementById('artifactRating');
  if (ratingWrap) renderRatingInto(ratingWrap, item);

  // Action-Buttons (zusammengeführt zu einem Download-Menü)
  // Im Viewer alle Artefakte anbieten — HTML als Offline-Export ist hilfreich.
  const actions = document.getElementById('artifactViewerActions');
  renderDownloadMenu(actions, item, item.formatId);

  // Body je nach Format / verfügbarem Artefakt
  const body = document.getElementById('artifactViewerBody');
  body.innerHTML = '';
  const htmlArt = (item.artifacts || []).find(a => a.kind === 'html');
  const pdfArt  = (item.artifacts || []).find(a => a.kind === 'pdf');
  const imgArt  = (item.artifacts || []).find(a => a.kind === 'image');

  if (htmlArt) {
    const frame = document.createElement('iframe');
    frame.className = 'lp-viewer-frame';
    frame.src = htmlArt.url;
    if (item.formatId === 'learningpath') {
      frame.onload = () => {
        frame.contentWindow?.postMessage({ type: 'SET_LIBRARY_ID', libraryId: item.id }, '*');
        if (item.progress) {
          frame.contentWindow?.postMessage({ type: 'RESTORE_PROGRESS', progress: item.progress }, '*');
        }
      };
    }
    body.appendChild(frame);
  } else if (pdfArt) {
    const frame = document.createElement('iframe');
    frame.className = 'lp-viewer-pdf';
    frame.src = pdfArt.url;
    body.appendChild(frame);
  } else if (imgArt) {
    body.innerHTML = `<div class="lp-viewer-md-wrap"><div class="lp-viewer-md" style="text-align:center;padding:24px"><img src="${imgArt.url}" alt="${esc(item.title)}" style="max-width:100%;height:auto;border-radius:8px"></div></div>`;
  } else if (item.formatId === 'pptx_deck') {
    body.innerHTML = renderPptxPreview(item);
  } else if (item.output) {
    body.innerHTML = `<div class="lp-viewer-md-wrap"><div class="lp-viewer-md markdown-body">${markdownToHtml(item.output)}</div></div>`;
  } else {
    body.innerHTML = `<div class="lp-viewer-download"><div class="download-icon">📦</div><p>Inhalt nicht verfügbar.<br>Falls Download-Buttons oben angezeigt werden, kannst du die Dateien herunterladen.</p></div>`;
  }
}

// ── Compliance-Panel ──────────────────────────────────────────────────────
function populateCompliancePanel(item) {
  // Klassifizierung (live editierbar)
  const cls = document.getElementById('cpClassification');
  if (cls) {
    cls.innerHTML = Object.entries(CLASSIFICATION_LABELS).map(([key, v]) =>
      `<option value="${key}">${v.icon} ${v.label}</option>`).join('');
    cls.value = item.classification || 'internal';
    cls.onchange = async () => {
      await patchLibraryItem(item.id, { classification: cls.value });
      item.classification = cls.value;
      const local = libraryItems.find(x => x.id === item.id);
      if (local) local.classification = cls.value;
      // Badges in der Topbar aktualisieren
      const badgeRow = document.getElementById('artifactBadges');
      if (badgeRow) {
        const validity = computeValidityStatus(item.validUntil);
        badgeRow.innerHTML =
          renderClassificationBadge(cls.value) +
          (validity !== 'none' ? renderValidityBadge(validity, item.validUntil) : '');
      }
    };
  }

  // Validität
  const val = document.getElementById('cpValidity');
  const valStatus = document.getElementById('cpValidityStatus');
  if (val) {
    val.innerHTML = `
      <option value="">Unbegrenzt</option>
      <option value="30">noch 30 Tage</option>
      <option value="90">noch 90 Tage</option>
      <option value="180">noch 6 Monate</option>
      <option value="365">noch 12 Monate</option>
      <option value="__keep__" hidden></option>
    `;
    if (item.validUntil) {
      const due = new Date(item.validUntil);
      const daysLeft = Math.ceil((due - Date.now()) / 86400000);
      const opt = val.querySelector('option[value="__keep__"]');
      opt.hidden = false;
      opt.textContent = `Aktuell: bis ${due.toLocaleDateString('de-DE')} (${daysLeft >= 0 ? daysLeft + ' Tage' : 'abgelaufen'})`;
      val.value = '__keep__';
      const status = computeValidityStatus(item.validUntil);
      valStatus.className = 'cp-status ' + (status === 'expired' ? 'error' : status === 'warn' ? 'warning' : '');
      valStatus.textContent = status === 'expired'
        ? '⚠ Inhalt ist abgelaufen — bitte aktualisieren oder neu generieren.'
        : status === 'warn'
        ? `⏰ Läuft in ${daysLeft} Tagen ab.`
        : '✓ Aktuell.';
    } else {
      val.value = '';
      valStatus.className = 'cp-status';
      valStatus.textContent = 'Unbegrenzt gültig.';
    }
    val.onchange = async () => {
      const v = val.value;
      if (v === '__keep__') return;
      let newVal;
      if (v === '') newVal = null;
      else newVal = new Date(Date.now() + Number(v) * 86400000).toISOString();
      await patchLibraryItem(item.id, { validUntil: newVal });
      item.validUntil = newVal;
      const local = libraryItems.find(x => x.id === item.id);
      if (local) local.validUntil = newVal;
      populateCompliancePanel(item);
      // Badges
      const badgeRow = document.getElementById('artifactBadges');
      if (badgeRow) {
        const validity = computeValidityStatus(item.validUntil);
        badgeRow.innerHTML =
          (item.classification ? renderClassificationBadge(item.classification) : '') +
          (validity !== 'none' ? renderValidityBadge(validity, item.validUntil) : '');
      }
    };
  }

  // Quellen
  const srcList = document.getElementById('cpSources');
  if (srcList) {
    const sources = item.sources || [];
    let inner = '';
    if (item.webSearchUsed) {
      inner += '<li class="src-websearch">🌐 Websuche / KI-Eigenwissen</li>';
    }
    if (sources.length > 0) {
      inner += sources.map(s => {
        const icon = ({ pdf:'📄', image:'🖼️', url:'🌐', text:'📝' })[s.type] || '📎';
        const link = s.url ? `<a class="src-link" href="${esc(s.url)}" target="_blank" rel="noopener">↗</a>` : '';
        return `<li><span class="src-icon">${icon}</span><span class="src-name" title="${esc(s.name)}">${esc(s.name)}</span>${link}</li>`;
      }).join('');
    }
    if (!inner) inner = '<li class="src-empty">Keine Quellen erfasst.</li>';
    srcList.innerHTML = inner;
  }

  // Feedback
  const fb = document.getElementById('cpFeedback');
  const fbStatus = document.getElementById('cpFeedbackStatus');
  const fbBtn = document.getElementById('cpFeedbackSave');
  if (fb) fb.value = item.feedback || '';
  if (fbStatus) { fbStatus.textContent = ''; fbStatus.className = 'cp-status'; }
  if (fbBtn) {
    fbBtn.onclick = async () => {
      const text = fb.value.trim();
      try {
        await patchLibraryItem(item.id, { feedback: text });
        item.feedback = text;
        const local = libraryItems.find(x => x.id === item.id);
        if (local) local.feedback = text;
        fbStatus.className = 'cp-status success';
        fbStatus.textContent = '✓ Feedback gespeichert.';
      } catch (err) {
        fbStatus.className = 'cp-status error';
        fbStatus.textContent = 'Fehler: ' + err.message;
      }
    };
  }
}

async function patchLibraryItem(id, patch) {
  const r = await fetch(`/api/library/${id}`, {
    method: 'PATCH', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  if (!r.ok) throw new Error(r.statusText);
  return r.json();
}

// Erzeugt eine schöne Slide-Übersicht für pptx_deck-Items
function renderPptxPreview(item) {
  let spec = null;
  try { spec = JSON.parse(item.output || '{}'); } catch {}
  if (!spec || !Array.isArray(spec.slides)) {
    return `<div class="lp-viewer-download"><div class="download-icon">📊</div><p>Foliensatz wurde generiert.<br>Lade die <strong>.pptx</strong> oben rechts herunter, um sie in PowerPoint zu öffnen.</p></div>`;
  }
  const cover = `
    <div class="slide-preview slide-cover">
      <div class="slide-num">Cover</div>
      <h2>${esc(spec.title || item.title)}</h2>
      ${spec.subtitle ? `<p class="slide-sub">${esc(spec.subtitle)}</p>` : ''}
    </div>`;
  const slides = spec.slides.map((s, i) => {
    if (s.type === 'section') {
      return `
        <div class="slide-preview slide-section">
          <div class="slide-num">Folie ${i + 2} · Abschnitt</div>
          <h3>${esc(s.title || '')}</h3>
          ${s.subtitle ? `<p class="slide-sub">${esc(s.subtitle)}</p>` : ''}
        </div>`;
    }
    const bullets = Array.isArray(s.bullets) ? s.bullets : [];
    return `
      <div class="slide-preview slide-content">
        <div class="slide-num">Folie ${i + 2}</div>
        <h4>${esc(s.title || '')}</h4>
        ${bullets.length ? `<ul>${bullets.map(b => `<li>${esc(b)}</li>`).join('')}</ul>` : ''}
        ${s.notes ? `<details class="slide-notes"><summary>📝 Notizen</summary><p>${esc(s.notes)}</p></details>` : ''}
      </div>`;
  }).join('');
  return `
    <div class="lp-viewer-md-wrap">
      <div class="slide-preview-wrap">
        <div class="slide-preview-info">
          <strong>📊 PowerPoint-Vorschau</strong> · ${spec.slides.length + 1} Folien · Lade die .pptx herunter, um sie zu bearbeiten.
        </div>
        ${cover}${slides}
      </div>
    </div>`;
}

// ── Rating ────────────────────────────────────────────────────────────────
function renderRatingInto(wrap, item) {
  if (!wrap || !item) return;
  wrap.innerHTML = '';
  for (let i = 1; i <= 5; i++) {
    const star = document.createElement('button');
    star.type = 'button';
    star.className = 'rating-star' + ((item.rating || 0) >= i ? ' filled' : '');
    star.textContent = '★';
    star.title = `${i} Stern${i !== 1 ? 'e' : ''}`;
    star.addEventListener('click', () => setRating(item, i));
    wrap.appendChild(star);
  }
  if (item.rating > 0) {
    const clear = document.createElement('button');
    clear.type = 'button';
    clear.className = 'rating-star';
    clear.textContent = '✕';
    clear.style.color = '#9ca3af';
    clear.title = 'Bewertung entfernen';
    clear.addEventListener('click', () => setRating(item, 0));
    wrap.appendChild(clear);
  }
}

async function setRating(item, rating) {
  try {
    const r = await fetch(`/api/library/${item.id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating }),
    });
    if (!r.ok) throw new Error(r.statusText);
    item.rating = rating;
    const local = libraryItems.find(x => x.id === item.id);
    if (local) local.rating = rating;
    // Beide Rating-Widgets aktualisieren, falls beide sichtbar sind
    const viewerWrap = document.getElementById('artifactRating');
    const genWrap    = document.getElementById('generatorRating');
    if (viewerWrap && currentArtifactItem?.id === item.id) renderRatingInto(viewerWrap, item);
    if (genWrap && currentLibraryId === item.id && genWrap.style.display !== 'none') renderRatingInto(genWrap, item);
    renderLibraryGrid();
    renderRecentOnDashboard();
  } catch (err) {
    alert('Bewertung konnte nicht gespeichert werden: ' + err.message);
  }
}

// ── Iframe PostMessage (Lernpfad-Fortschritt + Zertifikat) ────────────────
async function onIframeMessage(e) {
  if (e.data?.type === 'SAVE_PROGRESS' && currentLibraryId) {
    await fetch(`/api/library/${currentLibraryId}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ progress: e.data.progress }),
    }).catch(() => {});
    const item = libraryItems.find(i => i.id === currentLibraryId);
    if (item) item.progress = e.data.progress;
  }
  if (e.data?.type === 'ISSUE_CERTIFICATE') {
    const cd = e.data.certData || {};
    try {
      const r = await fetch('/api/certificates', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...cd, libraryId: currentLibraryId }),
      });
      if (!r.ok) throw new Error(r.statusText);
      const cert = await r.json();
      // Antwort in iframe für QR-Generierung zurückspielen
      const frames = document.querySelectorAll('iframe');
      frames.forEach(f => f.contentWindow?.postMessage({
        type: 'CERTIFICATE_ISSUED', cert,
      }, '*'));
    } catch (err) {
      console.error('[cert] issue failed:', err);
    }
  }
}

// ── Certificates View ─────────────────────────────────────────────────────
let certificateItems = [];

async function loadCertificates() {
  const grid = document.getElementById('certGrid');
  if (!grid) return;
  try {
    const r = await fetch('/api/certificates');
    if (!r.ok) throw new Error(r.statusText);
    certificateItems = await r.json();
    renderCertificates();
  } catch (err) {
    grid.innerHTML = `<div class="error-state"><strong>Fehler:</strong> ${esc(err.message)}</div>`;
  }
}

function renderCertificates() {
  const grid = document.getElementById('certGrid');
  if (!grid) return;
  if (certificateItems.length === 0) {
    grid.innerHTML = `<div class="sources-empty"><span>🏆</span><p>Noch keine Zertifikate.<br>Schließe einen Lernpfad mit mindestens 75% ab, um eines zu erhalten.</p></div>`;
    return;
  }
  grid.innerHTML = '';
  certificateItems.forEach(c => {
    const date = new Date(c.issuedAt).toLocaleDateString('de-DE', { day: '2-digit', month: 'long', year: 'numeric' });
    const card = document.createElement('div');
    card.className = 'cert-card';
    card.innerHTML = `
      <div class="cert-card-header">
        <span class="cert-card-icon">🏆</span>
        <span class="cert-card-score">${c.score}%</span>
      </div>
      <div class="cert-card-recipient">Verliehen an</div>
      <div class="cert-card-name">${esc(c.recipientName)}</div>
      <div class="cert-card-topic">${esc(c.topic)}</div>
      <div class="cert-card-meta">
        <span>${date}</span>
        <span class="cert-card-id">${esc(c.id)}</span>
      </div>
      <div class="cert-card-actions">
        <a class="btn btn-outline btn-sm" href="/verify/${encodeURIComponent(c.id)}" target="_blank" rel="noopener">↗ Verifikation öffnen</a>
        <button class="btn btn-outline btn-sm cert-del-btn" data-id="${esc(c.id)}">🗑 Löschen</button>
      </div>`;
    card.querySelector('.cert-del-btn').addEventListener('click', async () => {
      if (!confirm(`Zertifikat für ${c.recipientName} löschen? Verifikations-Links werden ungültig.`)) return;
      await fetch(`/api/certificates/${c.id}`, { method: 'DELETE' });
      certificateItems = certificateItems.filter(x => x.id !== c.id);
      renderCertificates();
    });
    grid.appendChild(card);
  });
}

// ── Quellen hinzufügen ─────────────────────────────────────────────────────
async function addTextSource(content, name) {
  try {
    const r = await fetch('/api/sources/text', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, name }),
    });
    if (!r.ok) throw new Error((await r.json()).error);
    const s = await r.json();
    sources.push(s); selectedSrcs.add(s.id);
    renderSourceList(); updateSourceStats();
  } catch (err) { alert('Fehler: ' + err.message); }
}
async function uploadFile(file, statusId, refreshPage = false) {
  const el = document.getElementById(statusId);
  if (el) el.textContent = `⏳ ${file.name} wird hochgeladen…`;
  try {
    const fd = new FormData();
    fd.append('file', file);
    const r    = await fetch('/api/sources/upload', { method: 'POST', body: fd });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error);
    sources.push(data); selectedSrcs.add(data.id);
    if (el) el.textContent = `✓ ${file.name} geladen`;
    renderSourceList(); updateSourceStats();
    if (refreshPage) renderSourcesPage();
  } catch (err) { if (el) el.textContent = `✗ Fehler: ${err.message}`; }
}
async function addUrlSource(url, statusId, refreshPage = false) {
  const el = document.getElementById(statusId);
  if (el) el.textContent = '⏳ Lade URL…';
  try {
    const r    = await fetch('/api/sources/url', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error);
    sources.push(data); selectedSrcs.add(data.id);
    if (el) el.textContent = `✓ ${data.name} geladen`;
    renderSourceList(); updateSourceStats();
    if (refreshPage) renderSourcesPage();
  } catch (err) { if (el) el.textContent = `✗ Fehler: ${err.message}`; }
}

// ── Markdown → HTML ────────────────────────────────────────────────────────
function markdownToHtml(md) {
  let h = esc(md);
  // Code-Blöcke (triple backticks) ZUERST — sonst zerlegen Single-Backticks die Fence-Marker
  h = h.replace(/```[\w]*\n([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
  h = h.replace(/^#{6} (.+)$/gm, '<h6>$1</h6>');
  h = h.replace(/^#{5} (.+)$/gm, '<h5>$1</h5>');
  h = h.replace(/^#{4} (.+)$/gm, '<h4>$1</h4>');
  h = h.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  h = h.replace(/^## (.+)$/gm,  '<h2>$1</h2>');
  h = h.replace(/^# (.+)$/gm,   '<h1>$1</h1>');
  h = h.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/\*(.+?)\*/g,     '<em>$1</em>');
  h = h.replace(/`([^`]+)`/g,     '<code>$1</code>');
  h = h.replace(/^\s*[-*] (.+)$/gm, '<li>$1</li>');
  h = h.replace(/(<li>[\s\S]+?<\/li>)/g, '<ul>$1</ul>');
  h = h.replace(/<\/ul>\s*<ul>/g, '');
  h = h.replace(/\n\n/g, '</p><p>');
  h = '<p>' + h + '</p>';
  h = h.replace(/<p>\s*(<(?:h[1-6]|ul|ol|pre|blockquote)>)/g, '$1');
  h = h.replace(/(<\/(?:h[1-6]|ul|ol|pre|blockquote)>)\s*<\/p>/g, '$1');
  return h;
}

// ── Helpers ────────────────────────────────────────────────────────────────
function esc(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
function formatBytes(b) {
  if (!b) return '';
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1024 / 1024).toFixed(1) + ' MB';
}
function formatDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('de-DE', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

// ── Download-Menü ──────────────────────────────────────────────────────────
// Sammelt alle herunterladbaren Repräsentationen eines Artefakts und
// rendert einen einzigen Button mit Dropdown-Menü.
const DOWNLOAD_KIND_META = {
  pdf:      { icon: '📄', label: 'PDF',          ext: 'pdf',  desc: 'Druckfertig, gebrandet'    },
  pptx:     { icon: '📊', label: 'PowerPoint',   ext: 'pptx', desc: 'Editierbar in Office'      },
  html:     { icon: '🌐', label: 'HTML',         ext: 'html', desc: 'Interaktiv, offline lauffähig' },
  image:    { icon: '🖼️', label: 'Bild',         ext: '',     desc: 'Original-Datei'            },
  markdown: { icon: '📝', label: 'Markdown',     ext: 'md',   desc: 'Roh-Text mit Formatierung' },
  json:     { icon: '⚙️', label: 'JSON',         ext: 'json', desc: 'Roh-Datenstruktur'         },
};

function buildDownloadOptions(item, formatId) {
  const opts = [];
  // Echte Artefakte vom Server
  (item.artifacts || []).forEach(a => {
    const meta = DOWNLOAD_KIND_META[a.kind] || { icon: '📎', label: a.kind.toUpperCase(), desc: '' };
    opts.push({
      kind:     a.kind,
      label:    meta.label,
      icon:     meta.icon,
      desc:     meta.desc,
      filename: a.filename,
      url:      a.url,
      size:     a.size,
    });
  });

  // Markdown / JSON aus dem rohen Output ableiten (Blob-URL on demand)
  const out = item.output || '';
  const baseName = sanitizeForFilename(item.title || item.topic || formatId || 'adcraft');
  if (out) {
    const isJson = (formatId === 'flashcards' || formatId === 'pptx_deck' || formatId === 'learningpath');
    if (isJson) {
      opts.push({
        kind:     'json',
        label:    DOWNLOAD_KIND_META.json.label,
        icon:     DOWNLOAD_KIND_META.json.icon,
        desc:     DOWNLOAD_KIND_META.json.desc,
        filename: `${baseName}.json`,
        url:      makeBlobUrl(out, 'application/json'),
        size:     out.length,
      });
    } else {
      opts.push({
        kind:     'markdown',
        label:    DOWNLOAD_KIND_META.markdown.label,
        icon:     DOWNLOAD_KIND_META.markdown.icon,
        desc:     DOWNLOAD_KIND_META.markdown.desc,
        filename: `${baseName}.md`,
        url:      makeBlobUrl(out, 'text/markdown; charset=utf-8'),
        size:     out.length,
      });
    }
  }
  return opts;
}

const _blobUrlCache = new Map();
function makeBlobUrl(text, mime) {
  const key = mime + ':' + text.length + ':' + text.slice(0, 80);
  if (_blobUrlCache.has(key)) return _blobUrlCache.get(key);
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  _blobUrlCache.set(key, url);
  return url;
}

function sanitizeForFilename(s) {
  return String(s).trim()
    .replace(/[^\p{L}\p{N}\s_-]/gu, '')
    .replace(/\s+/g, '-')
    .slice(0, 80) || 'adcraft';
}

function renderDownloadMenu(container, item, formatId) {
  container.innerHTML = '';
  const options = buildDownloadOptions(item, formatId || item.formatId);
  if (options.length === 0) return;

  const wrap = document.createElement('div');
  wrap.className = 'download-menu';
  const showCount = options.length > 1;
  wrap.innerHTML = `
    <button class="btn btn-primary btn-sm download-trigger" type="button" aria-haspopup="menu" aria-expanded="false">
      <span class="download-trigger-icon">↓</span>
      <span>Download</span>
      ${showCount ? `<span class="download-trigger-count">${options.length}</span>` : ''}
      <span class="download-trigger-caret">▾</span>
    </button>
    <div class="download-panel" role="menu">
      <div class="download-panel-header">${options.length === 1 ? 'Verfügbares Format' : 'Verfügbare Formate'}</div>
      ${options.map(o => `
        <a class="download-option" href="${esc(o.url)}" download="${esc(o.filename)}" role="menuitem">
          <span class="download-option-icon">${o.icon}</span>
          <span class="download-option-body">
            <span class="download-option-label">${esc(o.label)}</span>
            <span class="download-option-desc">${esc(o.desc)}</span>
          </span>
          <span class="download-option-meta">${o.size ? formatBytes(o.size) : ''}</span>
        </a>
      `).join('')}
    </div>
  `;
  container.appendChild(wrap);

  const trigger = wrap.querySelector('.download-trigger');
  const panel   = wrap.querySelector('.download-panel');

  function positionPanel() {
    const rect = trigger.getBoundingClientRect();
    const panelW = panel.offsetWidth || 340;
    const panelH = panel.offsetHeight || 280;
    const margin = 12;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    // Bevorzugt rechtsbündig zum Trigger; fallback linksbündig wenn das raussticht.
    let left = rect.right - panelW;
    if (left < margin) left = Math.min(rect.left, vw - panelW - margin);
    if (left < margin) left = margin;

    // Bevorzugt unter dem Trigger; flippt nach oben falls unten kein Platz.
    let top = rect.bottom + 8;
    if (top + panelH > vh - margin) {
      const above = rect.top - 8 - panelH;
      if (above >= margin) top = above;
      else top = Math.max(margin, vh - panelH - margin);
    }
    panel.style.left = left + 'px';
    panel.style.top  = top + 'px';
  }

  function open() {
    closeAllDownloadMenus();
    wrap.classList.add('open');
    trigger.setAttribute('aria-expanded', 'true');
    positionPanel();
    // Bei Resize / Scroll im Hintergrund: Panel mitführen
    window.addEventListener('resize', positionPanel);
    window.addEventListener('scroll', positionPanel, true);
    wrap._reposition = positionPanel;
  }
  function close() {
    wrap.classList.remove('open');
    trigger.setAttribute('aria-expanded', 'false');
    if (wrap._reposition) {
      window.removeEventListener('resize', wrap._reposition);
      window.removeEventListener('scroll', wrap._reposition, true);
      wrap._reposition = null;
    }
  }
  function toggle() { wrap.classList.contains('open') ? close() : open(); }

  trigger.addEventListener('click', e => { e.stopPropagation(); toggle(); });
  panel.addEventListener('click', e => {
    if (e.target.closest('.download-option')) {
      setTimeout(close, 60);
    }
  });

  return wrap;
}

function closeAllDownloadMenus() {
  document.querySelectorAll('.download-menu.open').forEach(m => {
    m.classList.remove('open');
    m.querySelector('.download-trigger')?.setAttribute('aria-expanded', 'false');
    if (m._reposition) {
      window.removeEventListener('resize', m._reposition);
      window.removeEventListener('scroll', m._reposition, true);
      m._reposition = null;
    }
  });
}

// Globale Click-/Esc-Schließer
document.addEventListener('click', e => {
  if (!e.target.closest('.download-menu')) closeAllDownloadMenus();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeAllDownloadMenus();
});

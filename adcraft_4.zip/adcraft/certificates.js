/**
 * Certificate Store
 * -----------------
 * Persistente Zertifikate die nicht im iframe-localStorage stecken.
 * Pro bestandenem Lernpfad ein Eintrag mit:
 *   { id, recipientName, topic, libraryId, score, totalQuestions,
 *     correctAnswers, issuedAt, language, level }
 *
 * Die Cert-ID kann öffentlich verifiziert werden über GET /verify/<id>.
 */

const fs   = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = path.join(__dirname, '../data/certificates');
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

function newId() {
  // Lesbar + URL-safe + nicht erratbar
  return 'adC-' + new Date().getFullYear() + '-' +
         crypto.randomBytes(4).toString('hex').toUpperCase();
}

function fileFor(id) {
  // Defensiver Pfad: nur erlaubte Zeichen
  if (!/^[A-Za-z0-9_-]+$/.test(id)) return null;
  return path.join(DIR, `${id}.json`);
}

function list() {
  return fs.readdirSync(DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => { try { return JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); } catch { return null; } })
    .filter(Boolean)
    .sort((a, b) => new Date(b.issuedAt) - new Date(a.issuedAt));
}

function get(id) {
  const file = fileFor(id);
  if (!file || !fs.existsSync(file)) return null;
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return null; }
}

function create(data) {
  const id = newId();
  const entry = {
    id,
    recipientName: String(data.recipientName || '').slice(0, 120).trim(),
    topic:         String(data.topic         || '').slice(0, 200).trim(),
    libraryId:     data.libraryId || null,
    score:         Number(data.score)         || 0,           // 0–100
    totalQuestions:  Number(data.totalQuestions)  || 0,
    correctAnswers:  Number(data.correctAnswers)  || 0,
    totalSteps:    Number(data.totalSteps)    || 0,
    language:      data.language || 'de',
    level:         data.level || null,
    issuedAt:      new Date().toISOString(),
  };
  if (!entry.recipientName || !entry.topic) {
    throw new Error('recipientName und topic sind erforderlich');
  }
  const file = fileFor(id);
  if (!file) throw new Error('Ungültige Zertifikats-ID');
  fs.writeFileSync(file, JSON.stringify(entry, null, 2));
  return entry;
}

function remove(id) {
  const file = fileFor(id);
  if (file && fs.existsSync(file)) fs.unlinkSync(file);
}

module.exports = { list, get, create, remove };

/**
 * Source ingestion
 * ----------------
 * Centralizes how different source types are turned into a uniform
 * in-memory representation that providers can consume.
 *
 * Stored shape (for everything):
 *   {
 *     id, type, name, addedAt,
 *     content?    // text, pdf, url
 *     data?       // image: base64 (no prefix)
 *     mediaType?  // image: e.g. "image/png"
 *     length      // chars (text) or bytes (image)
 *     meta?       // extra info (page count, source url, ...)
 *   }
 */

const cheerio = require('cheerio');

// pdf-parse has a buggy "demo runner" when loaded via require('pdf-parse')
// (it tries to read a sample PDF from disk). Loading the lib file directly avoids it.
const pdfParse = require('pdf-parse/lib/pdf-parse.js');

const ALLOWED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];
const MAX_PDF_CHARS = 200_000; // safety cap on extracted text

async function ingestText({ name, content }) {
  if (!name || !content) throw new Error('name und content sind erforderlich');
  return {
    type: 'text',
    name,
    content,
    length: content.length,
  };
}

async function ingestPdf({ name, buffer }) {
  if (!buffer || !buffer.length) throw new Error('PDF-Datei ist leer');
  const data = await pdfParse(buffer);
  let text = (data.text || '').trim();
  if (!text) {
    throw new Error(
      'Aus dem PDF konnte kein Text extrahiert werden (vermutlich ein gescanntes Bild-PDF — OCR ist nicht implementiert).'
    );
  }
  if (text.length > MAX_PDF_CHARS) {
    text = text.slice(0, MAX_PDF_CHARS) + '\n\n[…gekürzt…]';
  }
  return {
    type: 'pdf',
    name,
    content: text,
    length: text.length,
    meta: { pages: data.numpages },
  };
}

async function ingestImage({ name, mimetype, buffer }) {
  if (!ALLOWED_IMAGE_TYPES.includes(mimetype)) {
    throw new Error(
      `Bildformat ${mimetype} wird nicht unterstützt. Erlaubt: PNG, JPEG, WebP, GIF.`
    );
  }
  return {
    type: 'image',
    name,
    mediaType: mimetype,
    data: buffer.toString('base64'),
    length: buffer.length,
  };
}

async function ingestUrl({ url }) {
  if (!url) throw new Error('URL ist erforderlich');
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error(`Ungültige URL: ${url}`);
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error('Nur http:// und https:// werden unterstützt');
  }

  const res = await fetch(url, {
    headers: {
      'User-Agent': 'adCraft/1.0 (Learning material generator)',
    },
    redirect: 'follow',
  });

  if (!res.ok) {
    throw new Error(`URL konnte nicht abgerufen werden (HTTP ${res.status})`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('text/html') && !contentType.includes('text/plain')) {
    throw new Error(
      `Inhaltstyp ${contentType} wird nicht unterstützt (nur HTML/Text)`
    );
  }

  const html = await res.text();
  const { title, text } = extractReadableText(html);
  if (!text || text.length < 100) {
    throw new Error('Es konnte kein verwertbarer Text aus der Seite extrahiert werden.');
  }

  const trimmed = text.length > MAX_PDF_CHARS
    ? text.slice(0, MAX_PDF_CHARS) + '\n\n[…gekürzt…]'
    : text;

  return {
    type: 'url',
    name: title || parsed.hostname + parsed.pathname,
    content: trimmed,
    length: trimmed.length,
    meta: { url, host: parsed.hostname },
  };
}

function extractReadableText(html) {
  const $ = cheerio.load(html);
  // strip noise
  $('script, style, noscript, iframe, nav, header, footer, aside, form, button').remove();
  const title = ($('title').first().text() || '').trim();
  // prefer <article> or <main> if present
  const root = $('article').first().length
    ? $('article').first()
    : $('main').first().length
    ? $('main').first()
    : $('body');

  const text = root
    .text()
    .replace(/\u00A0/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  return { title, text };
}

module.exports = { ingestText, ingestPdf, ingestImage, ingestUrl };

require('dotenv').config();
const path    = require('path');
const fs      = require('fs');
const crypto  = require('crypto');
const express = require('express');
const multer  = require('multer');

const { getProvider, getImageProvider }    = require('./providers');
const { listFormats, getDepthProfile } = require('./prompts');
const promptVersions                       = require('./promptVersions');
const sourceIngest                         = require('./sources');
const { renderMarkdownToPdf, shutdown: shutdownPdf } = require('./pdfRenderer');
const { renderFlashcardsHtml, renderLearningPathHtml, renderQuickSheetHtml } = require('./htmlRenderer');
const { renderPptx, parseSlideSpec }       = require('./pptxRenderer');
const library                              = require('./library');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '15mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── In-memory stores ────────────────────────────────────────────────────────
const sources       = new Map();
let   sourceIdCounter = 1;
const artifacts     = new Map();

// Persistent artifact directory — so library entries survive a restart.
const ARTIFACT_DIR = path.join(__dirname, '../data/artifacts');
if (!fs.existsSync(ARTIFACT_DIR)) fs.mkdirSync(ARTIFACT_DIR, { recursive: true });

function storeArtifact({ kind, filename, mediaType, buffer }) {
  const id     = crypto.randomBytes(8).toString('hex');
  const record = { id, kind, filename, mediaType, size: buffer.length, createdAt: new Date().toISOString() };
  // In-Memory für Schnellzugriff
  artifacts.set(id, { ...record, buffer });
  // Persistent für Library-Einträge
  try {
    fs.writeFileSync(path.join(ARTIFACT_DIR, `${id}.bin`), buffer);
    fs.writeFileSync(path.join(ARTIFACT_DIR, `${id}.json`), JSON.stringify(record));
  } catch (e) { console.warn('[artifact] persist failed:', e.message); }
  return record;
}
function loadArtifactFromDisk(id) {
  try {
    const meta = JSON.parse(fs.readFileSync(path.join(ARTIFACT_DIR, `${id}.json`), 'utf8'));
    const buffer = fs.readFileSync(path.join(ARTIFACT_DIR, `${id}.bin`));
    return { ...meta, buffer };
  } catch { return null; }
}
function summarizeArtifact(a) {
  return { id: a.id, kind: a.kind, filename: a.filename, mediaType: a.mediaType, size: a.size, url: `/api/artifacts/${a.id}`, createdAt: a.createdAt };
}
function addSource(record) {
  const id     = String(sourceIdCounter++);
  const stored = { id, addedAt: new Date().toISOString(), ...record };
  sources.set(id, stored);
  return stored;
}
function summarize(record) {
  const base = { id: record.id, type: record.type, name: record.name, addedAt: record.addedAt, length: record.length, meta: record.meta || null };
  if (record.type === 'image') base.preview = `data:${record.mediaType};base64,${record.data}`;
  else if (record.content) base.preview = record.content.slice(0, 200);
  return base;
}

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

// ── Formats & Provider ──────────────────────────────────────────────────────
app.get('/api/formats', (_req, res) => res.json(listFormats()));
app.get('/api/provider', (_req, res) => {
  try {
    const p = getProvider();
    res.json({ name: p.getName(), model: p.defaultModel || null });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── Prompt Versions ─────────────────────────────────────────────────────────
app.get('/api/prompt-versions/:formatId', (req, res) => {
  const data = promptVersions.listVersions(req.params.formatId);
  if (!data) return res.status(404).json({ error: 'Unbekanntes Format' });
  res.json(data);
});

app.post('/api/prompt-versions/:formatId', (req, res) => {
  try {
    const { name, systemPrompt, userPrompt } = req.body || {};
    const v = promptVersions.createVersion(req.params.formatId, { name, systemPrompt, userPrompt });
    res.json(v);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.patch('/api/prompt-versions/:formatId/:versionId', (req, res) => {
  try {
    const v = promptVersions.updateVersion(req.params.formatId, req.params.versionId, req.body || {});
    if (!v) return res.status(404).json({ error: 'Version nicht gefunden' });
    res.json(v);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.delete('/api/prompt-versions/:formatId/:versionId', (req, res) => {
  try {
    res.json(promptVersions.deleteVersion(req.params.formatId, req.params.versionId));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.post('/api/prompt-versions/:formatId/active', (req, res) => {
  try {
    const { versionId } = req.body || {};
    res.json(promptVersions.setActive(req.params.formatId, versionId));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// ── Sources ─────────────────────────────────────────────────────────────────
app.get('/api/sources', (_req, res) => res.json([...sources.values()].map(summarize)));
app.delete('/api/sources/:id', (req, res) => res.json({ deleted: sources.delete(req.params.id) }));

app.post('/api/sources/text', async (req, res) => {
  try {
    const record = await sourceIngest.ingestText(req.body || {});
    res.json(summarize(addSource(record)));
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.post('/api/sources/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Keine Datei übermittelt' });
    const { mimetype, originalname, buffer } = req.file;
    let record;
    if (mimetype === 'application/pdf' || /\.pdf$/i.test(originalname))
      record = await sourceIngest.ingestPdf({ name: originalname, buffer });
    else if (mimetype.startsWith('image/'))
      record = await sourceIngest.ingestImage({ name: originalname, mimetype, buffer });
    else if (mimetype.startsWith('text/') || /\.(txt|md|csv|json)$/i.test(originalname))
      record = await sourceIngest.ingestText({ name: originalname, content: buffer.toString('utf-8') });
    else return res.status(400).json({ error: `Dateityp ${mimetype} wird nicht unterstützt.` });
    res.json(summarize(addSource(record)));
  } catch (err) { console.error('[upload] error:', err); res.status(400).json({ error: err.message }); }
});

app.post('/api/sources/url', async (req, res) => {
  try {
    const record = await sourceIngest.ingestUrl(req.body || {});
    res.json(summarize(addSource(record)));
  } catch (err) { console.error('[url] error:', err); res.status(400).json({ error: err.message }); }
});

// ── Generate ─────────────────────────────────────────────────────────────────
app.post('/api/generate', async (req, res) => {
  try {
    const { formatId, topic, sourceIds = [], providerName, language = 'de', level = 'intermediate', depth = 'standard', audience = '', webSearch = true } = req.body || {};
    if (!formatId || !topic) return res.status(400).json({ error: 'formatId und topic sind erforderlich' });

    // Aktive (ggf. benutzerdefinierte) Version verwenden.
    const prompt = promptVersions.getActivePrompt(formatId);
    if (!prompt) return res.status(400).json({ error: `unbekanntes Format: ${formatId}` });

    // Coming-Soon-Formate sind nicht generierbar.
    const fmtMeta = listFormats().find(f => f.id === formatId);
    if (fmtMeta?.comingSoon) {
      return res.status(400).json({ error: `Format „${fmtMeta.label}" ist noch in Vorbereitung.` });
    }

    const selectedSources = sourceIds
      .map(id => sources.get(id)).filter(Boolean)
      .map(({ type, name, content, data, mediaType }) =>
        type === 'image' ? { type, name, data, mediaType } : { type, name, content });

    // Mindestens eine Quelle erforderlich, wenn Websuche aus ist
    if (!webSearch && selectedSources.length === 0) {
      return res.status(400).json({ error: 'Websuche ist deaktiviert — bitte mindestens eine Quelle wählen.' });
    }

    const provider = getProvider(providerName);

    // Tiefen-Profil für Lernpfad berechnen.
    const dp = getDepthProfile(depth);
    const replacements = {
      '{topic}':       topic,
      '{language}':    language,
      '{level}':       level,
      '{depth}':       depth,
      '{audience}':    audience || 'allgemein',
      '{lpSteps}':     String(dp.steps),
      '{lpQuiz}':      String(dp.quiz),
      '{lpStepWords}': String(dp.stepWords),
    };
    const userPrompt   = applyReplacements(prompt.userPrompt   || '', replacements);
    let   systemPrompt = applyReplacements(prompt.systemPrompt || '', replacements);

    // Strenge Quellen-Bindung erzwingen, wenn Websuche aus ist
    if (!webSearch) {
      systemPrompt += '\n\nWICHTIG: Stütze dich AUSSCHLIESSLICH auf die mitgegebenen Quellen. ' +
        'Erfinde nichts, was nicht in den Quellen steht. Kennzeichne fehlende Information explizit.';
    }

    const result = await provider.generateText({
      systemPrompt,
      userPrompt,
      sources: selectedSources,
      options: prompt.options || {},
    });

    const generatedArtifacts = [];
    const isJson        = formatId === 'flashcards' || formatId === 'pptx_deck' || formatId === 'learningpath';
    const baseFilename  = sanitizeFilename(`${formatId}-${topic}`);

    generatedArtifacts.push(summarizeArtifact(storeArtifact({
      kind: isJson ? 'json' : 'markdown',
      filename: `${baseFilename}.${isJson ? 'json' : 'md'}`,
      mediaType: isJson ? 'application/json' : 'text/markdown; charset=utf-8',
      buffer: Buffer.from(result.text, 'utf-8'),
    })));

    if (prompt.pdf) {
      try {
        const pdfBuffer = await renderMarkdownToPdf({ markdown: result.text, title: topic, subtitle: prompt.label });
        generatedArtifacts.push(summarizeArtifact(storeArtifact({ kind: 'pdf', filename: `${baseFilename}.pdf`, mediaType: 'application/pdf', buffer: pdfBuffer })));
      } catch (pdfErr) { console.error('[pdf] rendering failed:', pdfErr); }
    }

    // Quick-Sheet bekommt zusätzlich ein gebrandetes HTML-Render fürs Inline-Preview
    if (formatId === 'quick_sheet') {
      try {
        const buffer = renderQuickSheetHtml({ markdown: result.text, title: topic });
        generatedArtifacts.push(summarizeArtifact(storeArtifact({ kind: 'html', filename: `${baseFilename}.html`, mediaType: 'text/html; charset=utf-8', buffer })));
      } catch (e) { console.error('[quick-sheet html] failed:', e); }
    }

    if (prompt.htmlRenderer) {
      try {
        const htmlBuffer = renderHtmlForFormat(prompt.htmlRenderer, { rawOutput: result.text, topic });
        if (htmlBuffer) generatedArtifacts.push(summarizeArtifact(storeArtifact({ kind: 'html', filename: `${baseFilename}.html`, mediaType: 'text/html; charset=utf-8', buffer: htmlBuffer })));
      } catch (htmlErr) { console.error('[html] rendering failed:', htmlErr); }
    }

    if (prompt.pptxRenderer === 'deck') {
      try {
        const spec       = parseSlideSpec(result.text);
        const pptxBuffer = await renderPptx({ spec, images: new Map() });
        generatedArtifacts.push(summarizeArtifact(storeArtifact({ kind: 'pptx', filename: `${baseFilename}.pptx`, mediaType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', buffer: pptxBuffer })));
      } catch (pptxErr) { console.error('[pptx] rendering failed:', pptxErr); }
    }

    if (prompt.imageGeneration) {
      try {
        const imageProvider = getImageProvider();
        const img  = await imageProvider.generateImage({ prompt: result.text.trim() });
        const ext  = img.mediaType.includes('png') ? 'png' : 'jpg';
        generatedArtifacts.push(summarizeArtifact(storeArtifact({ kind: 'image', filename: `${baseFilename}.${ext}`, mediaType: img.mediaType, buffer: img.buffer })));
      } catch (imgErr) {
        console.error('[image] generation failed:', imgErr);
        return res.status(500).json({ error: `Bildgenerierung fehlgeschlagen: ${imgErr.message}` });
      }
    }

    res.json({
      provider: provider.getName(),
      model: result.model,
      usage: result.usage,
      output: result.text,
      formatId,
      artifacts: generatedArtifacts,
      // Source-Snapshot fürs spätere Speichern in der Library (Compliance/Nachvollziehbarkeit)
      sourceSnapshot: sourceIds
        .map(id => sources.get(id))
        .filter(Boolean)
        .map(s => ({
          name:   s.name,
          type:   s.type,
          length: s.length || null,
          url:    s.meta?.url || null,
          host:   s.meta?.host || null,
        })),
      webSearchUsed: !!webSearch,
    });
  } catch (err) { console.error('[generate] error:', err); res.status(500).json({ error: err.message || 'generation failed' }); }
});

// ── Artifacts ────────────────────────────────────────────────────────────────
app.get('/api/artifacts/:id', (req, res) => {
  let a = artifacts.get(req.params.id);
  if (!a) {
    // Aus Library wiedereröffnete Items → von der Disk laden
    a = loadArtifactFromDisk(req.params.id);
    if (a) artifacts.set(a.id, a);
  }
  if (!a) return res.status(404).json({ error: 'Artefakt nicht gefunden' });
  res.setHeader('Content-Type', a.mediaType);
  res.setHeader('Content-Disposition', `${a.kind === 'html' || a.kind === 'pdf' ? 'inline' : 'attachment'}; filename="${encodeURIComponent(a.filename)}"`);
  res.send(a.buffer);
});

// ── Library ──────────────────────────────────────────────────────────────────
app.get('/api/library',        (_req, res) => res.json(library.list()));
app.get('/api/library/:id',    (req,  res) => {
  const e = library.get(req.params.id);
  e ? res.json(e) : res.status(404).json({ error: 'Not found' });
});
app.post('/api/library', (req, res) => {
  const entry = req.body;
  if (!entry?.title || !entry?.formatId) return res.status(400).json({ error: 'title + formatId required' });
  res.json(library.save(entry));
});
app.patch('/api/library/:id', (req, res) => {
  const updated = library.update(req.params.id, req.body);
  updated ? res.json(updated) : res.status(404).json({ error: 'Not found' });
});
app.delete('/api/library/:id', (req, res) => {
  library.remove(req.params.id);
  res.json({ ok: true });
});

// ── Certificates ────────────────────────────────────────────────────────────
const certificates = require('./certificates');

app.get('/api/certificates', (_req, res) => res.json(certificates.list()));
app.get('/api/certificates/:id', (req, res) => {
  const c = certificates.get(req.params.id);
  c ? res.json(c) : res.status(404).json({ error: 'Zertifikat nicht gefunden' });
});
app.post('/api/certificates', async (req, res) => {
  try {
    const cert = certificates.create(req.body || {});
    // QR-Code zur öffentlichen Verifikation generieren
    const verifyUrl = buildVerifyUrl(req, cert.id);
    let qrDataUrl = null;
    try {
      const QRCode = require('qrcode');
      qrDataUrl = await QRCode.toDataURL(verifyUrl, { width: 220, margin: 0, errorCorrectionLevel: 'M' });
    } catch (e) {
      console.warn('[cert] QR generation failed:', e.message);
    }
    res.json({ ...cert, verifyUrl, qrDataUrl });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

function buildVerifyUrl(req, certId) {
  const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').split(',')[0];
  const host  = req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`;
  return `${proto}://${host}/verify/${encodeURIComponent(certId)}`;
}
app.delete('/api/certificates/:id', (req, res) => {
  certificates.remove(req.params.id);
  res.json({ ok: true });
});

// Öffentliche Verifikations-Seite (Ziel des QR-Codes auf Zertifikaten)
app.get('/verify/:id', (req, res) => {
  const c = certificates.get(req.params.id);
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(renderVerifyPage(c, req.params.id));
});

function renderVerifyPage(cert, requestedId) {
  const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const styles = `
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Fira Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f6f8fb;color:#111827;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
    .v-card{background:#fff;border-radius:14px;box-shadow:0 12px 36px rgba(15,23,42,.10);max-width:520px;width:100%;padding:36px 40px;border-top:4px solid #006ec7}
    .v-brand{display:flex;align-items:center;gap:8px;margin-bottom:20px}
    .v-pill{width:8px;height:18px;background:#006ec7;border-radius:4px}
    .v-brand-name{font-weight:800;color:#006ec7;font-size:1.15rem;letter-spacing:-.02em}
    .v-status{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.12em;padding:6px 14px;border-radius:999px;display:inline-block;margin-bottom:18px}
    .v-status.ok{background:#dcfce7;color:#166534}
    .v-status.fail{background:#fee2e2;color:#991b1b}
    .v-headline{font-size:1.4rem;font-weight:700;color:#111827;letter-spacing:-.01em;margin-bottom:18px;line-height:1.3}
    .v-row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #eef2f7;font-size:.92rem}
    .v-row:last-child{border-bottom:none}
    .v-label{color:#647082;font-weight:500}
    .v-value{color:#111827;font-weight:600;text-align:right}
    .v-foot{margin-top:22px;padding-top:18px;border-top:1px solid #eef2f7;font-size:.78rem;color:#8593a5;text-align:center;line-height:1.55}
    .v-cert-id{font-family:'JetBrains Mono',ui-monospace,monospace;font-size:.78rem;color:#647082;margin-top:6px}
  `;
  if (!cert) {
    return `<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"><title>Verifizierung · adCraft</title><style>${styles}</style></head><body>
      <div class="v-card">
        <div class="v-brand"><span class="v-pill"></span><span class="v-brand-name">adCraft</span></div>
        <span class="v-status fail">✗ Ungültig</span>
        <h1 class="v-headline">Kein Zertifikat zu dieser ID gefunden</h1>
        <p style="color:#647082;font-size:.9rem;line-height:1.6">
          Die angefragte Zertifikats-ID <strong>${esc(requestedId)}</strong> existiert nicht in unserem System.
          Bitte prüfe den QR-Code oder wende dich an den Aussteller.
        </p>
        <div class="v-foot">adCraft Verifikationsdienst · ${new Date().toLocaleDateString('de-DE')}</div>
      </div>
    </body></html>`;
  }
  const issued = new Date(cert.issuedAt).toLocaleDateString('de-DE', { day:'2-digit', month:'long', year:'numeric' });
  return `<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Zertifikat verifiziert · adCraft</title><style>${styles}</style></head><body>
    <div class="v-card">
      <div class="v-brand"><span class="v-pill"></span><span class="v-brand-name">adCraft</span></div>
      <span class="v-status ok">✓ Verifiziert</span>
      <h1 class="v-headline">Dieses Zertifikat ist authentisch.</h1>
      <div class="v-row"><span class="v-label">Verliehen an</span><span class="v-value">${esc(cert.recipientName)}</span></div>
      <div class="v-row"><span class="v-label">Lernpfad</span><span class="v-value">${esc(cert.topic)}</span></div>
      <div class="v-row"><span class="v-label">Quiz-Ergebnis</span><span class="v-value">${cert.score}% (${cert.correctAnswers}/${cert.totalQuestions})</span></div>
      <div class="v-row"><span class="v-label">Ausgestellt am</span><span class="v-value">${issued}</span></div>
      <div class="v-foot">
        adCraft Verifikationsdienst<br>
        <span class="v-cert-id">${esc(cert.id)}</span>
      </div>
    </div>
  </body></html>`;
}

// ── Health & Start ───────────────────────────────────────────────────────────
app.get('/healthz', (_req, res) => res.json({ ok: true }));

const server = app.listen(PORT, () => {
  console.log(`adCraft running on http://localhost:${PORT}`);
  console.log(`Provider: ${process.env.LLM_PROVIDER || 'adesso-ai-hub'}`);
});

async function gracefulExit(signal) {
  console.log(`\n[${signal}] shutting down…`);
  await shutdownPdf().catch(() => {});
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on('SIGINT',  () => gracefulExit('SIGINT'));
process.on('SIGTERM', () => gracefulExit('SIGTERM'));

function sanitizeFilename(s) {
  return String(s).toLowerCase()
    .replace(/[äöüß]/g, c => ({ ä:'ae', ö:'oe', ü:'ue', ß:'ss' }[c]))
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || 'output';
}

function applyReplacements(template, repl) {
  let out = String(template);
  for (const [k, v] of Object.entries(repl)) {
    out = out.split(k).join(v);
  }
  return out;
}

function renderHtmlForFormat(rendererId, { rawOutput, topic }) {
  switch (rendererId) {
    case 'flashcards':   return renderFlashcardsHtml({ jsonText: rawOutput, fallbackTopic: topic });
    case 'learningpath': return renderLearningPathHtml({ jsonText: rawOutput, fallbackTopic: topic });
    default: console.warn(`[html] unknown renderer: ${rendererId}`); return null;
  }
}

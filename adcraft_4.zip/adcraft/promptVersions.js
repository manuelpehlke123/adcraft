/**
 * Prompt Versions
 * ---------------
 * Pro Format können Anwender benutzerdefinierte Prompt-Versionen anlegen.
 * Der "Default" stammt aus prompts.js und ist NICHT löschbar.
 * Eine Version pro Format ist als "aktiv" markiert — sie wird beim Generieren
 * verwendet. Default ist immer initial aktiv.
 *
 * Persistenz: data/prompt-versions/<formatId>.json
 *   { activeId: "default", versions: [
 *     { id, name, systemPrompt, userPrompt, isDefault, createdAt, updatedAt }
 *   ]}
 */

const fs   = require('fs');
const path = require('path');
const crypto = require('crypto');

const { getPrompt } = require('./prompts');

const DIR = path.join(__dirname, '../data/prompt-versions');
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

function fileFor(formatId) {
  return path.join(DIR, `${sanitizeId(formatId)}.json`);
}
function sanitizeId(s) {
  return String(s).replace(/[^a-z0-9_-]/gi, '_');
}

function defaultVersionFor(formatId) {
  const base = getPrompt(formatId);
  if (!base) return null;
  return {
    id: 'default',
    name: 'Standard',
    systemPrompt: base.systemPrompt || '',
    userPrompt:   base.userPrompt   || '',
    isDefault: true,
    createdAt: new Date(0).toISOString(),
    updatedAt: new Date(0).toISOString(),
  };
}

function readStore(formatId) {
  const file = fileFor(formatId);
  if (!fs.existsSync(file)) return { activeId: 'default', versions: [] };
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return { activeId: 'default', versions: [] }; }
}

function writeStore(formatId, store) {
  fs.writeFileSync(fileFor(formatId), JSON.stringify(store, null, 2));
}

/** Vollständiger Versions-Snapshot — Default wird immer live aus prompts.js gezogen. */
function listVersions(formatId) {
  const store = readStore(formatId);
  const def   = defaultVersionFor(formatId);
  if (!def) return null;
  // Default zuerst, danach Custom in createdAt-Reihenfolge.
  const customs = (store.versions || []).filter(v => !v.isDefault);
  return {
    formatId,
    activeId: store.activeId || 'default',
    versions: [def, ...customs],
  };
}

function getVersion(formatId, versionId) {
  if (versionId === 'default' || !versionId) return defaultVersionFor(formatId);
  const store = readStore(formatId);
  return (store.versions || []).find(v => v.id === versionId) || null;
}

/** Gibt den effektiv zu verwendenden Prompt für die Generierung zurück. */
function getActivePrompt(formatId) {
  const store = readStore(formatId);
  const base  = getPrompt(formatId);
  if (!base) return null;
  if (!store.activeId || store.activeId === 'default') return base;
  const v = (store.versions || []).find(x => x.id === store.activeId);
  if (!v) return base;
  return {
    ...base,
    systemPrompt: v.systemPrompt,
    userPrompt:   v.userPrompt,
  };
}

function createVersion(formatId, { name, systemPrompt, userPrompt }) {
  if (!getPrompt(formatId)) throw new Error('Unbekanntes Format: ' + formatId);
  const store = readStore(formatId);
  const id = 'v_' + crypto.randomBytes(6).toString('hex');
  const now = new Date().toISOString();
  const version = {
    id,
    name: (name || 'Unbenannt').slice(0, 80),
    systemPrompt: systemPrompt || '',
    userPrompt:   userPrompt   || '',
    isDefault: false,
    createdAt: now,
    updatedAt: now,
  };
  store.versions = store.versions || [];
  store.versions.push(version);
  writeStore(formatId, store);
  return version;
}

function updateVersion(formatId, versionId, patch) {
  if (versionId === 'default') throw new Error('Standard-Version kann nicht bearbeitet werden.');
  const store = readStore(formatId);
  const idx = (store.versions || []).findIndex(v => v.id === versionId);
  if (idx < 0) return null;
  const merged = {
    ...store.versions[idx],
    ...('name'         in patch ? { name: String(patch.name).slice(0, 80) } : {}),
    ...('systemPrompt' in patch ? { systemPrompt: patch.systemPrompt } : {}),
    ...('userPrompt'   in patch ? { userPrompt: patch.userPrompt }     : {}),
    updatedAt: new Date().toISOString(),
  };
  store.versions[idx] = merged;
  writeStore(formatId, store);
  return merged;
}

function deleteVersion(formatId, versionId) {
  if (versionId === 'default') throw new Error('Standard-Version kann nicht gelöscht werden.');
  const store = readStore(formatId);
  const before = (store.versions || []).length;
  store.versions = (store.versions || []).filter(v => v.id !== versionId);
  // Falls die aktive Version gelöscht wurde, fällt sie auf Default zurück.
  if (store.activeId === versionId) store.activeId = 'default';
  writeStore(formatId, store);
  return { deleted: store.versions.length < before };
}

function setActive(formatId, versionId) {
  if (!getPrompt(formatId)) throw new Error('Unbekanntes Format: ' + formatId);
  if (versionId !== 'default') {
    const store = readStore(formatId);
    if (!(store.versions || []).some(v => v.id === versionId)) {
      throw new Error('Version nicht gefunden: ' + versionId);
    }
    store.activeId = versionId;
    writeStore(formatId, store);
    return { activeId: versionId };
  }
  const store = readStore(formatId);
  store.activeId = 'default';
  writeStore(formatId, store);
  return { activeId: 'default' };
}

module.exports = {
  listVersions,
  getVersion,
  getActivePrompt,
  createVersion,
  updateVersion,
  deleteVersion,
  setActive,
};

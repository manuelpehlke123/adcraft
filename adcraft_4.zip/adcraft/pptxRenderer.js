const PptxGenJS = require('pptxgenjs');

const BRAND = {
  blue: '006EC7',
  blueDark: '004E8E',
  blueLight: 'E6F2FB',
  gray100: 'F1F4F7',
  gray400: '8FA3B4',
  gray600: '4F6272',
  gray900: '192330',
};

const FONT_HEADING = 'Calibri';
const FONT_BODY = 'Calibri';

async function renderPptx({ spec, images }) {
  const pptx = new PptxGenJS();
  pptx.layout = 'LAYOUT_WIDE';
  pptx.title = spec.title || 'adCraft Deck';
  pptx.author = 'adCraft';
  pptx.company = 'adesso';

  pptx.defineSlideMaster({
    title: 'AdessoBase',
    background: { color: 'FFFFFF' },
    objects: [
      { rect: { x: 0.4, y: 7.0, w: 0.12, h: 0.3, fill: { color: BRAND.blue } } },
      { text: { text: 'adCraft · adesso SE', options: { x: 0.6, y: 7.0, w: 6, h: 0.3, fontFace: FONT_BODY, fontSize: 9, color: BRAND.gray400 } } },
      { text: { text: '', options: { x: 12.0, y: 7.0, w: 1.0, h: 0.3, fontFace: FONT_BODY, fontSize: 9, color: BRAND.gray400, align: 'right' } }, placeholder: { options: { name: 'page-number', type: 'body', x: 12.0, y: 7.0, w: 1.0, h: 0.3 }, text: '' } },
    ],
    slideNumber: { x: 12.5, y: 7.0, w: 0.6, h: 0.3, fontFace: FONT_BODY, fontSize: 9, color: BRAND.gray400, align: 'right' },
  });

  addCover(pptx, { title: spec.title, subtitle: spec.subtitle });
  const slides = Array.isArray(spec.slides) ? spec.slides : [];
  slides.forEach((slide, idx) => addContent(pptx, slide, images && images.get(idx)));
  const base64 = await pptx.write({ outputType: 'base64' });
  return Buffer.from(base64, 'base64');
}

function addCover(pptx, { title, subtitle }) {
  const s = pptx.addSlide({ masterName: 'AdessoBase' });
  s.addShape('rect', { x: 0, y: 0, w: 0.4, h: 7.5, fill: { color: BRAND.blue }, line: { color: BRAND.blue } });
  s.addText('adCraft', { x: 0.8, y: 0.6, w: 8, h: 0.5, fontFace: FONT_HEADING, fontSize: 18, bold: true, color: BRAND.blue });
  // KI-generiert-Badge oben rechts
  s.addShape('roundRect', { x: 10.4, y: 0.55, w: 2.3, h: 0.4, fill: { color: 'FEF3C7' }, line: { color: 'FCD34D', width: 1 }, rectRadius: 0.18 });
  s.addText('🤖 KI-generiert', { x: 10.4, y: 0.55, w: 2.3, h: 0.4, fontFace: FONT_BODY, fontSize: 10, color: '92400E', align: 'center', valign: 'middle', bold: true });
  s.addText(title || 'Untitled', { x: 0.8, y: 2.4, w: 11.5, h: 2.0, fontFace: FONT_HEADING, fontSize: 44, bold: true, color: BRAND.gray900, valign: 'top' });
  if (subtitle) s.addText(subtitle, { x: 0.8, y: 4.6, w: 11.5, h: 1.0, fontFace: FONT_BODY, fontSize: 20, color: BRAND.gray600 });
  s.addText(new Date().toLocaleDateString('de-DE', { day: '2-digit', month: 'long', year: 'numeric' }), { x: 0.8, y: 6.5, w: 8, h: 0.3, fontFace: FONT_BODY, fontSize: 11, color: BRAND.gray400 });
}

function addContent(pptx, slide, image) {
  if (slide.type === 'section') return addSection(pptx, slide);
  const s = pptx.addSlide({ masterName: 'AdessoBase' });
  s.addShape('line', { x: 0.6, y: 0.55, w: 1.0, h: 0, line: { color: BRAND.blue, width: 3 } });
  s.addText(slide.title || '', { x: 0.6, y: 0.65, w: 12, h: 0.7, fontFace: FONT_HEADING, fontSize: 28, bold: true, color: BRAND.gray900 });
  const bullets = Array.isArray(slide.bullets) ? slide.bullets : [];
  const bodyY = 1.6, bodyH = 5.0;
  if (image) {
    s.addText(bulletsToTextBlocks(bullets), { x: 0.6, y: bodyY, w: 6.4, h: bodyH, fontFace: FONT_BODY, fontSize: 16, color: BRAND.gray900, valign: 'top', paraSpaceAfter: 6 });
    s.addImage({ data: `data:${image.mediaType};base64,${image.buffer.toString('base64')}`, x: 7.4, y: bodyY, w: 5.3, h: bodyH, sizing: { type: 'contain', w: 5.3, h: bodyH } });
  } else {
    s.addText(bulletsToTextBlocks(bullets), { x: 0.6, y: bodyY, w: 12.1, h: bodyH, fontFace: FONT_BODY, fontSize: 18, color: BRAND.gray900, valign: 'top', paraSpaceAfter: 8 });
  }
  if (slide.notes) s.addNotes(slide.notes);
}

function addSection(pptx, slide) {
  const s = pptx.addSlide({ masterName: 'AdessoBase' });
  s.addShape('rect', { x: 0, y: 0, w: 13.33, h: 7.5, fill: { color: BRAND.blue }, line: { color: BRAND.blue } });
  s.addText(slide.title || '', { x: 0.8, y: 3.2, w: 11.5, h: 1.5, fontFace: FONT_HEADING, fontSize: 40, bold: true, color: 'FFFFFF' });
  if (slide.subtitle) s.addText(slide.subtitle, { x: 0.8, y: 4.5, w: 11.5, h: 0.8, fontFace: FONT_BODY, fontSize: 18, color: BRAND.blueLight });
  if (slide.notes) s.addNotes(slide.notes);
}

function bulletsToTextBlocks(bullets) {
  if (!bullets || bullets.length === 0) return [{ text: '', options: {} }];
  return bullets.map((b) => ({ text: String(b), options: { bullet: { type: 'bullet', code: '25A0' }, color: BRAND.gray900 } }));
}

function parseSlideSpec(raw) {
  if (!raw) throw new Error('Leere Antwort');
  let cleaned = String(raw).trim();
  cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '');
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace > 0 && lastBrace > firstBrace) cleaned = cleaned.slice(firstBrace, lastBrace + 1);
  try { return JSON.parse(cleaned); } catch (err) { throw new Error(`Slide-Spec konnte nicht geparst werden: ${err.message}`); }
}

module.exports = { renderPptx, parseSlideSpec };

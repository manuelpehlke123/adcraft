// @ts-nocheck
/**
 * HTML Renderers — Flashcards + Learningpath
 */


// ── Flashcards ─────────────────────────────────────────────────────────────
function renderFlashcardsHtml({ jsonText, fallbackTopic }) {
  var data  = parseJson(jsonText);
  var topic = data.topic || fallbackTopic || 'Karteikarten';
  var cards = Array.isArray(data.cards) ? data.cards : [];
  return Buffer.from(buildFlashcardsHtml({ topic: topic, cards: cards }), 'utf-8');
}

function buildFlashcardsHtml({ topic, cards }) {
  var safeCards = JSON.stringify(cards).replace(/<\/script/gi, '<\\/script');
  return '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + esc(topic) + '</title>' +
    '<style>' +
    '*{box-sizing:border-box;margin:0;padding:0}' +
    'body{font-family:"Segoe UI",system-ui,sans-serif;background:#f4f6f9;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:32px 16px}' +
    'h1{font-size:1.4rem;font-weight:700;color:#192330;margin-bottom:8px;text-align:center}' +
    '.meta{font-size:.85rem;color:#8fa3b4;margin-bottom:32px}' +
    '.card-wrap{width:100%;max-width:600px;perspective:1200px}' +
    '.card{width:100%;min-height:220px;position:relative;transform-style:preserve-3d;transition:transform .5s cubic-bezier(.4,0,.2,1);cursor:pointer}' +
    '.card.flipped{transform:rotateY(180deg)}' +
    '.face{position:absolute;inset:0;backface-visibility:hidden;border-radius:16px;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px;box-shadow:0 4px 24px rgba(0,0,0,.10)}' +
    '.front{background:#fff;border:1px solid #dde3ec}' +
    '.back{background:#006ec7;color:#fff;transform:rotateY(180deg)}' +
    '.face p{font-size:1.1rem;line-height:1.6;text-align:center}' +
    '.face .label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;opacity:.5;margin-bottom:12px}' +
    '.controls{display:flex;align-items:center;gap:16px;margin-top:24px;width:100%;max-width:600px;justify-content:center}' +
    'button{padding:9px 22px;border-radius:24px;border:1px solid #dde3ec;background:#fff;color:#006ec7;font-weight:600;font-size:.85rem;cursor:pointer}' +
    'button:disabled{opacity:.35;cursor:not-allowed}' +
    '.counter{font-size:.85rem;color:#8fa3b4;min-width:80px;text-align:center}' +
    '.progress{width:100%;max-width:600px;height:4px;background:#dde3ec;border-radius:99px;margin-top:16px;overflow:hidden}' +
    '.progress-fill{height:100%;background:#006ec7;border-radius:99px;transition:width .4s}' +
    '.tags{display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin-top:12px}' +
    '.tag{font-size:.68rem;font-weight:700;padding:2px 8px;border-radius:8px;background:#e6f2fb;color:#006ec7}' +
    '.fc-ai-flag{position:fixed;top:14px;right:18px;font-size:.7rem;font-weight:600;background:#fef3c7;color:#92400e;border:1px solid #fcd34d;border-radius:12px;padding:3px 10px;z-index:10}' +
    '</style></head><body>' +
    '<span class="fc-ai-flag">🤖 KI-generiert</span>' +
    '<h1>' + esc(topic) + '</h1>' +
    '<p class="meta" id="meta"></p>' +
    '<div class="card-wrap"><div class="card" id="card" onclick="flip()">' +
    '<div class="face front"><span class="label">Frage</span><p id="front"></p></div>' +
    '<div class="face back"><span class="label" style="color:rgba(255,255,255,.6)">Antwort</span><p id="back"></p></div>' +
    '</div></div>' +
    '<div class="tags" id="tags"></div>' +
    '<div class="progress"><div class="progress-fill" id="bar"></div></div>' +
    '<div class="controls">' +
    '<button id="prevBtn" onclick="prev()">&#8592; Zur\u00fcck</button>' +
    '<span class="counter" id="counter"></span>' +
    '<button id="nextBtn" onclick="next()">Weiter &#8594;</button>' +
    '</div>' +
    '<script>' +
    'var cards=' + safeCards + ';var i=0;' +
    'function show(){var c=cards[i];document.getElementById("card").classList.remove("flipped");' +
    'setTimeout(function(){document.getElementById("front").textContent=c.front;document.getElementById("back").textContent=c.back;' +
    'document.getElementById("counter").textContent=(i+1)+" / "+cards.length;' +
    'document.getElementById("bar").style.width=((i+1)/cards.length*100)+"%";' +
    'document.getElementById("meta").textContent=cards.length+" Karten \u00b7 Tipp: Pfeile \u2190 \u2192 navigieren, Leertaste dreht";' +
    'var t=document.getElementById("tags");t.innerHTML=(c.tags||[]).map(function(x){return"<span class=\\"tag\\">"+x+"</span>";}).join("");' +
    'document.getElementById("prevBtn").disabled=i===0;document.getElementById("nextBtn").disabled=i===cards.length-1;},150);}' +
    'function flip(){document.getElementById("card").classList.toggle("flipped");}' +
    'function next(){if(i<cards.length-1){i++;show();}}' +
    'function prev(){if(i>0){i--;show();}}' +
    'document.addEventListener("keydown",function(e){' +
    '  if(e.key==="ArrowRight"){e.preventDefault();next();}' +
    '  else if(e.key==="ArrowLeft"){e.preventDefault();prev();}' +
    '  else if(e.key===" "||e.key==="Spacebar"){e.preventDefault();flip();}' +
    '});' +
    'show();' +
    '<\/script></body></html>';
}


// ── Learning Path ──────────────────────────────────────────────────────────
function renderLearningPathHtml({ jsonText, fallbackTopic }) {
  var data = parseJson(jsonText);
  return Buffer.from(buildLearningPathHtml(data, fallbackTopic), 'utf-8');
}

function buildLearningPathHtml(data, fallbackTopic) {
  var topic       = data.title || data.topic || fallbackTopic || 'Lernpfad';
  var description = data.description || '';
  var minutes     = data.estimatedMinutes || '?';
  var steps       = Array.isArray(data.steps) ? data.steps : [];
  var quiz        = Array.isArray(data.quiz)  ? data.quiz  : [];

  // Normalize: support both "correct" (0-based index) and "correctIndex"
  quiz = quiz.map(function(q) {
    var ci = q.correctIndex !== undefined ? q.correctIndex : (q.correct !== undefined ? q.correct : 0);
    return {
      question:     q.question || '',
      options:      Array.isArray(q.options) ? q.options : [],
      correctIndex: ci,
      explanation:  q.explanation || q.solution || ''
    };
  });

  var stepsJson = JSON.stringify(steps).replace(/<\/script/gi, '<\\/script');
  var quizJson  = JSON.stringify(quiz).replace(/<\/script/gi, '<\\/script');

  var css =
    '*{box-sizing:border-box;margin:0;padding:0}' +
    'body{font-family:"Segoe UI",system-ui,sans-serif;background:#f0f2f5;color:#192330;min-height:100vh}' +

    '.lp-header{background:linear-gradient(135deg,#004e8e 0%,#006ec7 60%,#0ea5e9 100%);padding:40px 32px 36px;color:#fff}' +
    '.lp-header h1{font-size:1.7rem;font-weight:700;margin-bottom:10px}' +
    '.lp-header p{font-size:.95rem;opacity:.85;line-height:1.65;max-width:720px;margin-bottom:18px}' +
    '.lp-meta{display:flex;gap:12px;flex-wrap:wrap;align-items:center}' +
    '.lp-badge{font-size:.78rem;font-weight:600;background:rgba(255,255,255,.18);border-radius:20px;padding:5px 14px}' +
    '.lp-ai-flag{font-size:.72rem;font-weight:600;background:rgba(255,255,255,.92);color:#92400e;border-radius:20px;padding:5px 12px;margin-left:auto}' +

    '.lp-body{max-width:860px;margin:0 auto;padding:32px 20px 80px}' +

    '.progress-wrap{background:#fff;border:1px solid #dde3ec;border-radius:12px;padding:18px 22px;margin-bottom:28px;box-shadow:0 1px 4px rgba(0,0,0,.05)}' +
    '.progress-label{font-size:.82rem;font-weight:600;color:#4f6272;margin-bottom:8px;display:flex;justify-content:space-between}' +
    '.progress-track{height:8px;background:#eef1f5;border-radius:99px;overflow:hidden}' +
    '.progress-fill{height:100%;background:linear-gradient(90deg,#006ec7,#38bdf8);border-radius:99px;transition:width .5s}' +

    '.step-item{display:flex;gap:0;position:relative;margin-bottom:0}' +
    '.step-line{position:absolute;left:17px;top:40px;bottom:0;width:2px;background:#dde3ec;z-index:0}' +
    '.step-item.done .step-line{background:#22c55e}' +
    '.step-dot{width:36px;height:36px;min-width:36px;border-radius:50%;border:2px solid #dde3ec;background:#fff;' +
    'display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:#8fa3b4;' +
    'margin-top:14px;position:relative;z-index:1;transition:all .3s}' +
    '.step-item.active .step-dot{border-color:#006ec7;color:#006ec7;background:#e6f2fb;box-shadow:0 0 0 4px rgba(0,110,199,.12)}' +
    '.step-item.done .step-dot{border-color:#22c55e;color:#22c55e;background:#f0fdf4}' +

    '.step-card{flex:1;margin-left:14px;margin-bottom:12px;background:#fff;border:1px solid #dde3ec;' +
    'border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.05)}' +
    '.step-header{padding:14px 18px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;' +
    'background:#fff;transition:background .15s;user-select:none}' +
    '.step-header:hover{background:#f8f9fb}' +
    '.step-item.active .step-header{background:#f0f6ff}' +
    '.step-item.done .step-header{background:#f6fef9}' +
    '.step-header-left{display:flex;flex-direction:column;gap:2px}' +
    '.step-num{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#8fa3b4}' +
    '.step-item.active .step-num{color:#006ec7}' +
    '.step-item.done .step-num{color:#22c55e}' +
    '.step-title-text{font-size:.97rem;font-weight:600;color:#192330}' +
    '.chevron{font-size:.75rem;color:#8fa3b4;transition:transform .25s;flex-shrink:0}' +
    '.step-item.open .chevron{transform:rotate(180deg)}' +

    '.step-body{display:none;padding:0 18px 18px;border-top:1px solid #eef1f5}' +
    '.step-item.open .step-body{display:block}' +
    '.step-text{font-size:.88rem;line-height:1.8;color:#374151;margin:16px 0;white-space:pre-wrap}' +

    '.task-box{background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:14px 16px;margin-top:4px}' +
    '.box-label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px}' +
    '.task-box .box-label{color:#1d4ed8}' +
    '.task-box p{font-size:.86rem;line-height:1.65;color:#1e3a8a}' +

    '.sol-wrap{margin-top:12px}' +
    '.sol-toggle{display:inline-flex;align-items:center;gap:6px;font-size:.8rem;font-weight:600;' +
    'color:#059669;cursor:pointer;padding:6px 14px;background:#f0fdf4;border:1px solid #bbf7d0;' +
    'border-radius:20px;transition:background .15s}' +
    '.sol-toggle:hover{background:#dcfce7}' +
    '.sol-box{display:none;margin-top:10px;background:#f0fdf4;border:1px solid #bbf7d0;' +
    'border-radius:10px;padding:14px 16px;font-size:.86rem;line-height:1.7;color:#166534;white-space:pre-wrap}' +
    '.sol-box.visible{display:block}' +

    '.step-footer{margin-top:16px;padding-top:14px;border-top:1px solid #eef1f5;display:flex;align-items:center;gap:12px}' +
    '.done-btn{padding:8px 20px;border-radius:20px;border:none;background:#006ec7;color:#fff;' +
    'font-weight:600;font-size:.82rem;cursor:pointer;transition:background .15s;flex-shrink:0}' +
    '.done-btn:hover:not(:disabled){background:#004e8e}' +
    '.done-btn.completed{background:#22c55e;cursor:default}' +
    '.done-hint{font-size:.75rem;color:#8fa3b4}' +

    '.quiz-section{margin-top:28px;background:#fff;border:1px solid #dde3ec;border-radius:16px;' +
    'box-shadow:0 1px 4px rgba(0,0,0,.05);overflow:hidden}' +
    '.quiz-header{padding:24px 28px 0}' +
    '.quiz-header h2{font-size:1.1rem;font-weight:700;margin-bottom:4px}' +
    '.quiz-sub{font-size:.82rem;color:#8fa3b4;margin-bottom:20px}' +
    '.quiz-locked{padding:0 28px 24px;font-size:.86rem;color:#8fa3b4}' +

    '.quiz-nav{padding:0 28px 28px;display:none}' +
    '.quiz-nav.active{display:block}' +
    '.q-progress{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}' +
    '.q-counter{font-size:.82rem;font-weight:600;color:#4f6272}' +
    '.q-dots{display:flex;gap:5px}' +
    '.q-dot{width:8px;height:8px;border-radius:50%;background:#dde3ec}' +
    '.q-dot.current{background:#006ec7}' +
    '.q-dot.correct{background:#22c55e}' +
    '.q-dot.wrong{background:#ef4444}' +

    '.q-card{background:#f8f9fb;border:1px solid #eef1f5;border-radius:12px;padding:22px}' +
    '.q-text{font-size:.95rem;font-weight:600;color:#192330;margin-bottom:18px;line-height:1.5}' +
    '.q-options{display:flex;flex-direction:column;gap:10px}' +
    '.q-opt{display:flex;align-items:center;gap:12px;padding:12px 16px;border:1.5px solid #dde3ec;' +
    'border-radius:10px;cursor:pointer;font-size:.87rem;background:#fff;transition:border-color .15s,background .15s;' +
    '-webkit-user-select:none;user-select:none}' +
    '.q-opt:hover:not(.locked){background:#f0f6ff;border-color:#93c5fd}' +
    '.q-opt.selected{border-color:#006ec7;background:#eff6ff}' +
    '.q-opt.correct{border-color:#22c55e;background:#f0fdf4;color:#166534;font-weight:600}' +
    '.q-opt.wrong{border-color:#ef4444;background:#fef2f2;color:#991b1b}' +
    '.q-opt-letter{width:26px;height:26px;min-width:26px;border-radius:50%;background:#eef1f5;' +
    'display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;color:#4f6272;flex-shrink:0}' +
    '.q-opt.selected .q-opt-letter{background:#006ec7;color:#fff}' +
    '.q-opt.correct .q-opt-letter{background:#22c55e;color:#fff}' +
    '.q-opt.wrong .q-opt-letter{background:#ef4444;color:#fff}' +
    '.q-exp{margin-top:14px;padding:12px 14px;background:#fff;border:1px solid #dde3ec;' +
    'border-radius:8px;font-size:.82rem;color:#4f6272;line-height:1.6;display:none}' +
    '.q-exp.visible{display:block}' +

    '.q-actions{margin-top:18px;display:flex;justify-content:space-between;align-items:center;gap:12px}' +
    '.q-btn{padding:9px 22px;border-radius:20px;border:none;font-weight:600;font-size:.85rem;cursor:pointer;transition:background .15s}' +
    '.q-btn-primary{background:#006ec7;color:#fff}' +
    '.q-btn-primary:hover:not(:disabled){background:#004e8e}' +
    '.q-btn-primary:disabled{opacity:.35;cursor:not-allowed}' +
    '.q-btn-secondary{background:#f4f6f9;color:#374151;border:1px solid #dde3ec}' +
    '.q-btn-secondary:hover{background:#eef1f5}' +

    '.quiz-result-wrap{padding:0 28px 28px;display:none}' +
    '.quiz-result{padding:20px 22px;border-radius:12px;font-size:.95rem;text-align:center;line-height:1.7}' +
    '.quiz-result.pass{background:#f0fdf4;border:1px solid #22c55e;color:#166534}' +
    '.quiz-result.fail{background:#fef2f2;border:1px solid #fca5a5;color:#991b1b}' +

    /* ── Zertifikat ───────────────────────────────── */
    '.cert-cta{margin-top:14px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap}' +
    '.cert-overlay{position:fixed;inset:0;background:rgba(15,23,42,.78);display:none;z-index:999;' +
    'align-items:flex-start;justify-content:center;padding:24px 16px;overflow:auto}' +
    '.cert-overlay.open{display:flex}' +
    '.cert-overlay-inner{background:#fff;border-radius:14px;width:min(900px,100%);max-width:100%;' +
    'box-shadow:0 24px 60px rgba(0,0,0,.4);overflow:hidden;display:flex;flex-direction:column}' +
    '.cert-toolbar{display:flex;align-items:center;gap:10px;padding:12px 18px;border-bottom:1px solid #eef1f5;background:#f8f9fb}' +
    '.cert-toolbar h3{font-size:.92rem;font-weight:700;color:#192330;flex:1}' +
    '.cert-toolbar .q-btn{padding:7px 16px;font-size:.78rem}' +
    '.cert-name-form{padding:36px 36px 32px;text-align:center;max-width:460px;margin:0 auto}' +
    '.cert-name-form h4{font-size:1.2rem;font-weight:700;color:#192330;margin-bottom:8px}' +
    '.cert-name-form p{font-size:.88rem;color:#4f6272;margin-bottom:22px;line-height:1.55}' +
    '.cert-name-input{width:100%;padding:11px 14px;border:1.5px solid #dde3ec;border-radius:8px;font-size:1rem;font-family:inherit;outline:none;transition:border-color .15s,box-shadow .15s;margin-bottom:18px;text-align:center}' +
    '.cert-name-input:focus{border-color:#006ec7;box-shadow:0 0 0 3px rgba(0,110,199,.12)}' +
    '.cert-name-actions{display:flex;gap:10px;justify-content:center}' +
    '.cert-page{padding:24px}' +
    '.cert{background:#fff;border:2px solid #e6f2fb;border-radius:14px;padding:46px 54px;position:relative;' +
    'background-image:linear-gradient(135deg,#fff 0%,#fbfdff 60%,#eef7ff 100%);' +
    'box-shadow:inset 0 0 0 6px #fff,inset 0 0 0 8px #006ec7;font-family:"Fira Sans","Segoe UI",sans-serif;color:#192330}' +
    '.cert-brand{display:flex;align-items:center;gap:10px;margin-bottom:10px}' +
    '.cert-brand-logo{width:14px;height:30px;background:#006ec7;border-radius:7px}' +
    '.cert-brand-name{font-weight:800;color:#006ec7;font-size:1.15rem;letter-spacing:-.02em}' +
    '.cert-eyebrow{font-size:.78rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:#8fa3b4;margin-bottom:18px}' +
    '.cert-headline{font-size:2.1rem;font-weight:800;letter-spacing:-.02em;line-height:1.05;margin-bottom:6px;color:#004e8e}' +
    '.cert-sub{font-size:.95rem;color:#4f6272;margin-bottom:30px}' +
    '.cert-recipient-label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.16em;color:#8fa3b4;margin-bottom:6px}' +
    '.cert-recipient{font-size:1.7rem;font-weight:700;color:#192330;border-bottom:2px solid #006ec7;padding-bottom:8px;margin-bottom:26px;display:inline-block;min-width:60%}' +
    '.cert-body{font-size:.95rem;line-height:1.7;color:#374151;margin-bottom:32px}' +
    '.cert-body strong{color:#004e8e}' +
    '.cert-stats{display:flex;gap:32px;flex-wrap:wrap;margin-bottom:30px;padding:14px 0;border-top:1px solid #e6f2fb;border-bottom:1px solid #e6f2fb}' +
    '.cert-stat{display:flex;flex-direction:column;gap:2px}' +
    '.cert-stat-num{font-size:1.4rem;font-weight:800;color:#006ec7;letter-spacing:-.02em}' +
    '.cert-stat-lbl{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#8fa3b4}' +
    '.cert-foot{display:flex;justify-content:space-between;align-items:flex-end;gap:24px;flex-wrap:wrap}' +
    '.cert-sig-block{flex:1;min-width:200px}' +
    '.cert-sig-line{height:1px;background:#192330;margin-bottom:6px}' +
    '.cert-sig-name{font-weight:600;font-size:.85rem;color:#192330}' +
    '.cert-sig-role{font-size:.74rem;color:#8fa3b4}' +
    '.cert-id{font-family:"JetBrains Mono",ui-monospace,monospace;font-size:.7rem;color:#8fa3b4;text-align:right}' +
    '.cert-qr{display:flex;flex-direction:column;align-items:center;gap:4px}' +
    '.cert-qr img{width:84px;height:84px;display:block;border:4px solid #fff}' +
    '.cert-qr span{font-size:.65rem;color:#8fa3b4;font-weight:600;text-transform:uppercase;letter-spacing:.06em}' +
    '.cert-spinner{width:32px;height:32px;border:3px solid #e6f2fb;border-top-color:#006ec7;border-radius:50%;animation:certSpin .8s linear infinite;margin:18px auto 0}' +
    '@keyframes certSpin{to{transform:rotate(360deg)}}' +
    '@media print{' +
      'body *{visibility:hidden!important}' +
      '.cert-overlay,.cert-overlay *{visibility:visible!important}' +
      '.cert-overlay{position:absolute;inset:0;background:#fff;padding:0}' +
      '.cert-overlay-inner{box-shadow:none;border-radius:0;width:100%}' +
      '.cert-toolbar{display:none!important}' +
      '.cert-page{padding:0}' +
      '.cert{border:none;box-shadow:none;page-break-inside:avoid}' +
    '}';

  var html =
    '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + esc(topic) + '</title>' +
    '<style>' + css + '</style></head><body>' +

    '<div class="lp-header">' +
    '<h1>' + esc(topic) + '</h1>' +
    '<p>' + esc(description) + '</p>' +
    '<div class="lp-meta">' +
    '<span class="lp-badge">&#9201; ' + esc(String(minutes)) + ' Min.</span>' +
    '<span class="lp-badge">' + steps.length + ' Lernschritte</span>' +
    '<span class="lp-badge">' + quiz.length + ' Quizfragen</span>' +
    '<span class="lp-ai-flag">🤖 KI-generiert</span>' +
    '</div></div>' +

    '<div class="lp-body">' +

    '<div class="progress-wrap">' +
    '<div class="progress-label"><span>Fortschritt</span><span id="progressLabel">0 / ' + steps.length + '</span></div>' +
    '<div class="progress-track"><div class="progress-fill" id="progressFill" style="width:0%"></div></div>' +
    '</div>' +

    '<div id="stepList"></div>' +

    '<div class="quiz-section">' +
    '<div class="quiz-header">' +
    '<h2>&#127891; Abschlussquiz</h2>' +
    '<p class="quiz-sub">Frage f\u00fcr Frage \u2014 mindestens 75% zum Bestehen</p>' +
    '</div>' +
    '<div id="quizLocked" class="quiz-locked">Schlie\u00dfe alle Lernschritte ab, um das Quiz freizuschalten.</div>' +
    '<div class="quiz-nav" id="quizNav"></div>' +
    '<div class="quiz-result-wrap" id="quizResultWrap"><div class="quiz-result" id="quizResult"></div></div>' +
    '</div>' +

    '</div>' +

    /* ── Zertifikats-Overlay ─────────────────────── */
    '<div class="cert-overlay" id="certOverlay" role="dialog" aria-modal="true">' +
    '<div class="cert-overlay-inner">' +
    '<div class="cert-toolbar">' +
    '<h3 id="certToolbarTitle">Zertifikat</h3>' +
    '<button class="q-btn q-btn-secondary" id="certPrintBtn" style="display:none" onclick="window.print()">&#128424; Drucken / PDF</button>' +
    '<button class="q-btn q-btn-secondary" onclick="closeCert()">Schlie\u00dfen</button>' +
    '</div>' +
    '<div class="cert-name-form" id="certNameForm">' +
    '<h4>Wie soll dein Zertifikat lauten?</h4>' +
    '<p>Gib deinen Namen ein, der auf dem Zertifikat erscheinen soll.</p>' +
    '<input type="text" id="certNameInput" class="cert-name-input" placeholder="Vor- und Nachname" autocomplete="name">' +
    '<div class="cert-name-actions">' +
    '<button class="q-btn q-btn-secondary" onclick="closeCert()">Abbrechen</button>' +
    '<button class="q-btn q-btn-primary" id="certCreateBtn">Zertifikat erstellen \u2192</button>' +
    '</div>' +
    '</div>' +
    '<div class="cert-page" id="certPage" style="display:none"><div id="certBody"></div></div>' +
    '</div></div>' +

    '<script>' +
    'var STEPS=' + stepsJson + ';' +
    'var QUIZ=' + quizJson + ';' +
    'var doneset=[];' +
    'var quizIndex=0;' +
    'var quizAnswers={};' +
    'var pendingAnswer=null;' +

    /* ── Progress-Sync mit Eltern-Fenster (Library) ── */
    'function pushProgress(){' +
    '  try{' +
    '    var totalPages=STEPS.length+1;' +
    '    var doneCount=doneset.length+(quizPassed?1:0);' +
    '    var p={' +
    '      doneCount:doneCount,' +
    '      totalPages:totalPages,' +
    '      completedSteps:doneset.slice(),' +
    '      quizAnswers:quizAnswers,' +
    '      quizPassed:quizPassed,' +
    '      quizScore:quizScore,' +
    '      updatedAt:new Date().toISOString()' +
    '    };' +
    '    if(window.parent&&window.parent!==window){window.parent.postMessage({type:"SAVE_PROGRESS",progress:p},"*");}' +
    '  }catch(e){}' +
    '}' +
    'var quizPassed=false;var quizScore=0;' +

    /* Restore aus Library beim Start */
    'window.addEventListener("message",function(ev){' +
    '  if(!ev.data||ev.data.type!=="RESTORE_PROGRESS"||!ev.data.progress)return;' +
    '  var p=ev.data.progress;' +
    '  if(p.completedSteps&&p.completedSteps.length){doneset=p.completedSteps.slice();applyRestoredSteps();}' +
    '  if(p.quizAnswers){quizAnswers=p.quizAnswers;}' +
    '  if(p.quizPassed){quizPassed=true;quizScore=p.quizScore||0;}' +
    '  updateProgress();' +
    '});' +
    'function applyRestoredSteps(){' +
    '  for(var k=0;k<doneset.length;k++){' +
    '    var i=doneset[k];' +
    '    var el=document.getElementById("step-"+i);if(!el)continue;' +
    '    el.classList.add("done");' +
    '    var dot=document.getElementById("dot-"+i);if(dot)dot.textContent="\u2713";' +
    '    var btn=document.getElementById("btn-"+i);if(btn){btn.textContent="\u2713 Abgeschlossen";btn.classList.add("completed");btn.disabled=true;}' +
    '  }' +
    '}' +

    'function updateProgress(){' +
    '  var pct=STEPS.length?Math.round(doneset.length/STEPS.length*100):0;' +
    '  document.getElementById("progressFill").style.width=pct+"%";' +
    '  document.getElementById("progressLabel").textContent=doneset.length+" / "+STEPS.length;' +
    '  if(doneset.length===STEPS.length)unlockQuiz();' +
    '}' +

    'function renderSteps(){' +
    '  var list=document.getElementById("stepList");' +
    '  var h="";' +
    '  for(var i=0;i<STEPS.length;i++){' +
    '    var s=STEPS[i];var last=i===STEPS.length-1;' +
    '    h+="<div class=\\"step-item\\" id=\\"step-"+i+"\\">";' +
    '    if(!last)h+="<div class=\\"step-line\\"></div>";' +
    '    h+="<div class=\\"step-dot\\" id=\\"dot-"+i+"\\">"+(i+1)+"</div>";' +
    '    h+="<div class=\\"step-card\\">";' +
    '    h+="<div class=\\"step-header\\" onclick=\\"toggleStep("+i+")\\">";' +
    '    h+="<div class=\\"step-header-left\\">";' +
    '    h+="<span class=\\"step-num\\">Schritt "+(i+1)+"</span>";' +
    '    h+="<span class=\\"step-title-text\\">"+e2(s.title||"")+"</span>";' +
    '    h+="</div>";' +
    '    h+="<span class=\\"chevron\\">&#9660;</span>";' +
    '    h+="</div>";' +
    '    h+="<div class=\\"step-body\\">";' +
    '    h+="<p class=\\"step-text\\">"+e2(s.content||"")+"</p>";' +
    '    if(s.task){' +
    '      h+="<div class=\\"task-box\\"><div class=\\"box-label\\">&#9999;&#65039; Aufgabe</div><p>"+e2(s.task)+"</p></div>";' +
    '    }' +
    '    if(s.solution){' +
    '      h+="<div class=\\"sol-wrap\\">";' +
    '      h+="<span class=\\"sol-toggle\\" onclick=\\"toggleSol("+i+")\\" id=\\"soltoggle-"+i+"\\">&#128161; L\u00f6sung anzeigen</span>";' +
    '      h+="<div class=\\"sol-box\\" id=\\"sol-"+i+"\\">"+e2(s.solution)+"</div>";' +
    '      h+="</div>";' +
    '    }' +
    '    h+="<div class=\\"step-footer\\">";' +
    '    h+="<button class=\\"done-btn\\" id=\\"btn-"+i+"\\" onclick=\\"markDone("+i+")\\">Als abgeschlossen markieren</button>";' +
    '    h+="<span class=\\"done-hint\\">Aufgabe erledigt? Hak ab und weiter.</span>";' +
    '    h+="</div>";' +
    '    h+="</div>";' +
    '    h+="</div>";' +
    '    h+="</div>";' +
    '  }' +
    '  list.innerHTML=h;' +
    '}' +

    'function toggleStep(i){' +
    '  var el=document.getElementById("step-"+i);' +
    '  var wasOpen=el.classList.contains("open");' +
    '  var all=document.querySelectorAll(".step-item");' +
    '  for(var j=0;j<all.length;j++){all[j].classList.remove("open","active");}' +
    '  if(!wasOpen){el.classList.add("open","active");}' +
    '}' +

    'function toggleSol(i){' +
    '  var box=document.getElementById("sol-"+i);' +
    '  var btn=document.getElementById("soltoggle-"+i);' +
    '  var visible=box.classList.toggle("visible");' +
    '  btn.innerHTML=visible?"&#128161; L\u00f6sung ausblenden":"&#128161; L\u00f6sung anzeigen";' +
    '}' +

    'function markDone(i){' +
    '  if(doneset.indexOf(i)>=0)return;' +
    '  doneset.push(i);' +
    '  var el=document.getElementById("step-"+i);' +
    '  el.classList.add("done");el.classList.remove("active","open");' +
    '  document.getElementById("dot-"+i).textContent="\u2713";' +
    '  var btn=document.getElementById("btn-"+i);' +
    '  btn.textContent="\u2713 Abgeschlossen";btn.classList.add("completed");btn.disabled=true;' +
    '  updateProgress();' +
    '  pushProgress();' +
    '  var next=i+1;' +
    '  if(next<STEPS.length){' +
    '    var nextEl=document.getElementById("step-"+next);' +
    '    if(nextEl){nextEl.classList.add("open","active");}' +
    '    nextEl.scrollIntoView({behavior:"smooth",block:"start"});' +
    '  }' +
    '}' +

    'function unlockQuiz(){' +
    '  document.getElementById("quizLocked").style.display="none";' +
    '  quizIndex=0;quizAnswers={};pendingAnswer=null;' +
    '  showQuestion(0);' +
    '  document.getElementById("quizNav").classList.add("active");' +
    '  document.querySelector(".quiz-section").scrollIntoView({behavior:"smooth",block:"start"});' +
    '}' +

    'function renderDots(){' +
    '  var h="";' +
    '  for(var i=0;i<QUIZ.length;i++){' +
    '    var cls="q-dot";' +
    '    if(quizAnswers.hasOwnProperty(i)){' +
    '      cls+=quizAnswers[i]===QUIZ[i].correctIndex?" correct":" wrong";' +
    '    }else if(i===quizIndex){cls+=" current";}' +
    '    h+="<div class=\\""+cls+"\\"></div>";' +
    '  }' +
    '  return h;' +
    '}' +

    'function showQuestion(qi){' +
    '  quizIndex=qi;pendingAnswer=null;' +
    '  var q=QUIZ[qi];' +
    '  var letters=["A","B","C","D","E","F"];' +
    '  var answered=quizAnswers.hasOwnProperty(qi);' +
    '  var chosen=answered?quizAnswers[qi]:-1;' +
    '  var h="";' +
    '  h+="<div class=\\"q-progress\\">";' +
    '  h+="<span class=\\"q-counter\\">Frage "+(qi+1)+" / "+QUIZ.length+"</span>";' +
    '  h+="<div class=\\"q-dots\\">"+renderDots()+"</div>";' +
    '  h+="</div>";' +
    '  h+="<div class=\\"q-card\\">";' +
    '  h+="<div class=\\"q-text\\">"+e2(q.question||"")+"</div>";' +
    '  h+="<div class=\\"q-options\\">";' +
    '  for(var oi=0;oi<(q.options||[]).length;oi++){' +
    '    var cls="q-opt";' +
    '    if(answered){' +
    '      cls+=" locked";' +
    '      if(oi===q.correctIndex)cls+=" correct";' +
    '      else if(oi===chosen)cls+=" wrong";' +
    '    }else{' +
    '      if(oi===chosen)cls+=" selected";' +
    '    }' +
    '    var clickHandler=answered?"":"onclick=\\"selectOpt("+qi+","+oi+")\\"";' +
    '    h+="<div class=\\""+cls+"\\" "+clickHandler+">";' +
    '    h+="<span class=\\"q-opt-letter\\">"+letters[oi]+"</span>";' +
    '    h+=e2(q.options[oi]);' +
    '    h+="</div>";' +
    '  }' +
    '  h+="</div>";' +
    '  if(answered){' +
    '    var correct=chosen===q.correctIndex;' +
    '    h+="<div class=\\"q-exp visible\\">";' +
    '    h+=correct?"<strong>&#10003; Richtig!</strong> ":"<strong>&#10007; Falsch.</strong> Die richtige Antwort war: <strong>"+e2(q.options[q.correctIndex])+"</strong>. ";' +
    '    h+=e2(q.explanation||"");' +
    '    h+="</div>";' +
    '  }' +
    '  h+="</div>";' +
    '  h+="<div class=\\"q-actions\\">";' +
    '  if(qi>0){h+="<button class=\\"q-btn q-btn-secondary\\" onclick=\\"showQuestion("+(qi-1)+")\\">\\u2190 Zur\u00fcck</button>";}' +
    '  else{h+="<span></span>";}' +
    '  if(!answered){' +
    '    h+="<button class=\\"q-btn q-btn-primary\\" id=\\"confirmBtn\\" onclick=\\"confirmAnswer("+qi+")\\" disabled>Best\u00e4tigen</button>";' +
    '  }else if(qi<QUIZ.length-1){' +
    '    h+="<button class=\\"q-btn q-btn-primary\\" onclick=\\"showQuestion("+(qi+1)+")\\">N\u00e4chste Frage \\u2192</button>";' +
    '  }else{' +
    '    h+="<button class=\\"q-btn q-btn-primary\\" onclick=\\"showResult()\\">Auswertung anzeigen</button>";' +
    '  }' +
    '  h+="</div>";' +
    '  document.getElementById("quizNav").innerHTML=h;' +
    '}' +

    // FIX: selectOpt nutzt jetzt oi-Parameter statt event.currentTarget
    'function selectOpt(qi,oi){' +
    '  if(quizAnswers.hasOwnProperty(qi))return;' +
    '  pendingAnswer=oi;' +
    '  var opts=document.querySelectorAll(".q-opt");' +
    '  for(var i=0;i<opts.length;i++){opts[i].classList.remove("selected");}' +
    '  var allOpts=document.querySelectorAll(".q-opt");' +
    '  if(allOpts[oi])allOpts[oi].classList.add("selected");' +
    '  var btn=document.getElementById("confirmBtn");' +
    '  if(btn)btn.disabled=false;' +
    '}' +

    'function confirmAnswer(qi){' +
    '  if(pendingAnswer===null||pendingAnswer===undefined)return;' +
    '  quizAnswers[qi]=pendingAnswer;' +
    '  pendingAnswer=null;' +
    '  showQuestion(qi);' +
    '}' +

    'function showResult(){' +
    '  var correct=0;' +
    '  for(var i=0;i<QUIZ.length;i++){' +
    '    if(quizAnswers[i]===QUIZ[i].correctIndex)correct++;' +
    '  }' +
    '  var pct=Math.round(correct/QUIZ.length*100);' +
    '  var passed=pct>=75;' +
    '  quizPassed=passed;quizScore=pct;' +
    '  pushProgress();' +
    '  document.getElementById("quizNav").classList.remove("active");' +
    '  var rw=document.getElementById("quizResultWrap");' +
    '  rw.style.display="block";' +
    '  var res=document.getElementById("quizResult");' +
    '  res.className="quiz-result "+(passed?"pass":"fail");' +
    '  if(passed){' +
    '    res.innerHTML="<strong>&#127881; Bestanden!</strong><br>"+correct+" / "+QUIZ.length+" richtig ("+pct+"%) &#8212; Lernpfad abgeschlossen!" +' +
    '      "<div class=\\"cert-cta\\"><button class=\\"q-btn q-btn-primary\\" onclick=\\"openCert("+correct+","+pct+")\\">&#127942; Zertifikat anzeigen</button></div>";' +
    '  }else{' +
    '    res.innerHTML="<strong>&#10060; Nicht bestanden</strong><br>"+correct+" / "+QUIZ.length+" richtig ("+pct+"%).<br>Mindestens 75% erforderlich.<br><br><button class=\\"q-btn q-btn-primary\\" style=\\"margin-top:8px\\" onclick=\\"retryQuiz()\\">Quiz wiederholen</button>";' +
    '  }' +
    '  rw.scrollIntoView({behavior:"smooth",block:"start"});' +
    '}' +

    /* ── Zertifikat ── */
    'function openCert(correct,pct){' +
    '  document.getElementById("certNameForm").style.display="";' +
    '  document.getElementById("certPage").style.display="none";' +
    '  document.getElementById("certPrintBtn").style.display="none";' +
    '  document.getElementById("certToolbarTitle").textContent="Zertifikat";' +
    '  var input=document.getElementById("certNameInput");' +
    '  var stored="";try{stored=window.localStorage.getItem("adcraft_cert_name")||"";}catch(e){}' +
    '  input.value=stored;' +
    '  document.getElementById("certCreateBtn").onclick=function(){buildCert(correct,pct);};' +
    '  input.onkeydown=function(ev){if(ev.key==="Enter"){ev.preventDefault();buildCert(correct,pct);}};' +
    '  document.getElementById("certOverlay").classList.add("open");' +
    '  setTimeout(function(){input.focus();input.select();},80);' +
    '}' +
    'function buildCert(correct,pct){' +
    '  var name=(document.getElementById("certNameInput").value||"").trim();' +
    '  if(!name){document.getElementById("certNameInput").focus();return;}' +
    '  try{window.localStorage.setItem("adcraft_cert_name",name);}catch(e){}' +
    /* Loading-State + Anfrage an Eltern-Fenster (das postet zum Server) */
    '  var formEl=document.getElementById("certNameForm");' +
    '  formEl.innerHTML="<h4>Zertifikat wird ausgestellt …</h4><p>Einen Moment bitte.</p><div class=\\"cert-spinner\\"></div>";' +
    '  var topic=' + JSON.stringify(topic) + ';' +
    '  if(window.parent&&window.parent!==window){' +
    '    window.parent.postMessage({type:"ISSUE_CERTIFICATE",certData:{recipientName:name,topic:topic,score:pct,correctAnswers:correct,totalQuestions:QUIZ.length,totalSteps:STEPS.length}},"*");' +
    '  }else{' +
    /* Fallback: kein Eltern-Fenster (Standalone-HTML) → Lokal rendern ohne Server-Cert */
    '    renderCertHtml(name,correct,pct,"adC-LOCAL-"+Math.random().toString(36).slice(2,8).toUpperCase(),null);' +
    '  }' +
    '}' +
    /* Antwort vom Eltern-Fenster mit ausgestellter Cert-ID + QR-Data-URL */
    'window.addEventListener("message",function(ev){' +
    '  if(!ev.data||ev.data.type!=="CERTIFICATE_ISSUED")return;' +
    '  var c=ev.data.cert;' +
    '  var name=c.recipientName;' +
    '  renderCertHtml(name,c.correctAnswers,c.score,c.id,c.qrDataUrl||null);' +
    '});' +
    'function renderCertHtml(name,correct,pct,certId,qrDataUrl){' +
    '  var today=new Date();' +
    '  var d=today.toLocaleDateString("de-DE",{day:"2-digit",month:"long",year:"numeric"});' +
    '  var topic=' + JSON.stringify(topic) + ';' +
    '  var html="";' +
    '  html+="<div class=\\"cert\\">";' +
    '  html+="<div class=\\"cert-brand\\"><span class=\\"cert-brand-logo\\"></span><span class=\\"cert-brand-name\\">adCraft</span></div>";' +
    '  html+="<div class=\\"cert-eyebrow\\">Teilnahmezertifikat</div>";' +
    '  html+="<h1 class=\\"cert-headline\\">Erfolgreich abgeschlossen</h1>";' +
    '  html+="<p class=\\"cert-sub\\">Dieses Zertifikat best\u00e4tigt den erfolgreichen Abschluss des folgenden Lernpfads.</p>";' +
    '  html+="<div class=\\"cert-recipient-label\\">Verliehen an</div>";' +
    '  html+="<div class=\\"cert-recipient\\">"+e2(name)+"</div>";' +
    '  html+="<p class=\\"cert-body\\">f\u00fcr den erfolgreichen Abschluss des Lernpfads <strong>&bdquo;"+e2(topic)+"&ldquo;</strong> sowie f\u00fcr das Bestehen des zugeh\u00f6rigen Abschlussquiz mit "+correct+" von "+QUIZ.length+" korrekten Antworten ("+pct+"%).</p>";' +
    '  html+="<div class=\\"cert-stats\\">";' +
    '  html+="<div class=\\"cert-stat\\"><span class=\\"cert-stat-num\\">"+pct+"%</span><span class=\\"cert-stat-lbl\\">Quiz-Ergebnis</span></div>";' +
    '  html+="<div class=\\"cert-stat\\"><span class=\\"cert-stat-num\\">"+STEPS.length+"</span><span class=\\"cert-stat-lbl\\">Lernschritte</span></div>";' +
    '  html+="<div class=\\"cert-stat\\"><span class=\\"cert-stat-num\\">"+QUIZ.length+"</span><span class=\\"cert-stat-lbl\\">Quizfragen</span></div>";' +
    '  html+="<div class=\\"cert-stat\\"><span class=\\"cert-stat-num\\">"+e2(d)+"</span><span class=\\"cert-stat-lbl\\">Ausstellungsdatum</span></div>";' +
    '  html+="</div>";' +
    '  html+="<div class=\\"cert-foot\\">";' +
    '  html+="<div class=\\"cert-sig-block\\"><div class=\\"cert-sig-line\\"></div><div class=\\"cert-sig-name\\">adCraft Lernplattform</div><div class=\\"cert-sig-role\\">Automatisiert ausgestellt</div></div>";' +
    '  if(qrDataUrl){' +
    '    html+="<div class=\\"cert-qr\\"><img src=\\""+qrDataUrl+"\\" alt=\\"QR-Code zur Verifikation\\"><span>Scannen zur Verifikation</span></div>";' +
    '  }' +
    '  html+="<div class=\\"cert-id\\">Zertifikat-ID<br>"+e2(certId)+"</div>";' +
    '  html+="</div></div>";' +
    '  document.getElementById("certBody").innerHTML=html;' +
    '  document.getElementById("certNameForm").style.display="none";' +
    '  document.getElementById("certPage").style.display="";' +
    '  document.getElementById("certPrintBtn").style.display="";' +
    '  document.getElementById("certToolbarTitle").textContent="Zertifikat \u00b7 "+name;' +
    '}' +
    'function closeCert(){document.getElementById("certOverlay").classList.remove("open");}' +
    'window.addEventListener("keydown",function(ev){if(ev.key==="Escape")closeCert();});' +

    'function retryQuiz(){' +
    '  quizAnswers={};quizIndex=0;pendingAnswer=null;' +
    '  document.getElementById("quizResultWrap").style.display="none";' +
    '  document.getElementById("quizNav").classList.add("active");' +
    '  showQuestion(0);' +
    '}' +

    'function e2(s){return String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");}' +
    'renderSteps();updateProgress();toggleStep(0);' +
    '<\/script></body></html>';

  return html;
}


// ── Shared helpers ─────────────────────────────────────────────────────────
function parseJson(raw) {
  if (!raw) throw new Error('Leere Antwort');
  var s = String(raw).trim();
  // Code-Fences entfernen (sowohl ```json als auch ```)
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/i, '');
  // Aus eventuell vorhandenem Prefix-Text (z.B. "Hier ist dein Lernpfad:") nur den JSON-Teil herausschneiden.
  var f = s.indexOf('{'), l = s.lastIndexOf('}');
  if (f >= 0 && l > f) s = s.slice(f, l + 1);

  // Versuch 1: direkt parsen
  try { return JSON.parse(s); } catch (_) {}

  // Versuch 2: häufige LLM-Pannen reparieren — trailing commas vor } oder ]
  var repaired = s.replace(/,(\s*[\]}])/g, '$1');
  try { return JSON.parse(repaired); } catch (_) {}

  // Versuch 3: Output ist eventuell trunkiert (Token-Limit erreicht).
  // Versuche, fehlende Klammern zuzubauen, indem wir vorne anfangen und Klammern zählen.
  var fixed = repairTruncatedJson(repaired);
  if (fixed) {
    try { return JSON.parse(fixed); } catch (_) {}
  }

  throw new Error('JSON konnte nicht geparst werden — Antwort vermutlich abgeschnitten oder ungültig formatiert.');
}

// Heuristik: Klammern und String-Quotes balancieren bis zum letzten erfolgreichen Token.
// Reicht nicht für jeden Fall, aber rettet die häufigsten Truncation-Probleme.
function repairTruncatedJson(s) {
  var stack = [];   // Klammerstack
  var inStr = false;
  var escape = false;
  var lastSafe = -1;     // Letzter Index, an dem der Wert „gut abschließbar" war
  for (var i = 0; i < s.length; i++) {
    var c = s.charAt(i);
    if (escape) { escape = false; continue; }
    if (inStr) {
      if (c === '\\') escape = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') { inStr = true; continue; }
    if (c === '{' || c === '[') { stack.push(c); continue; }
    if (c === '}' || c === ']') {
      stack.pop();
      if (stack.length > 0) lastSafe = i;
      continue;
    }
  }
  if (stack.length === 0) return null;       // Nicht trunkiert
  if (lastSafe < 0) return null;             // Nichts zu retten
  // Schneide bis zum letzten sauberen Wert, schließe dann offene Klammern.
  var trimmed = s.slice(0, lastSafe + 1);
  // Etwaige offene Klammern aus dem vollen Stack ableiten
  var stack2 = [];
  var inStr2 = false; var esc2 = false;
  for (var j = 0; j < trimmed.length; j++) {
    var cc = trimmed.charAt(j);
    if (esc2) { esc2 = false; continue; }
    if (inStr2) { if (cc === '\\') esc2 = true; else if (cc === '"') inStr2 = false; continue; }
    if (cc === '"') { inStr2 = true; continue; }
    if (cc === '{' || cc === '[') stack2.push(cc);
    else if (cc === '}' || cc === ']') stack2.pop();
  }
  while (stack2.length) {
    var open = stack2.pop();
    trimmed += (open === '{' ? '}' : ']');
  }
  return trimmed;
}

function esc(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}


// ── Quick-Sheet (Markdown → gebrandete HTML-"Seite") ───────────────────────
// Rendert Markdown im selben adesso/adCraft-Brandstil wie das PDF, aber als
// eigenständige HTML-Datei zum Inline-Einbetten via iframe.
function renderQuickSheetHtml({ markdown, title }) {
  // markdown-it ist eine Hauptabhängigkeit, also einfach reaktiv lazy laden.
  var MarkdownIt = require('markdown-it');
  var md = new MarkdownIt({ html: false, linkify: true, typographer: true, breaks: false });
  var bodyHtml = md.render(markdown || '');
  var t = esc(title || 'Quick-Sheet');

  var html =
    '<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>' + t + '</title>' +
    '<link rel="preconnect" href="https://fonts.googleapis.com">' +
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' +
    '<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300;400;600;700&family=Fira+Sans+Condensed:wght@700;800;900&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">' +
    '<style>' +
    ':root{--blue:#006ec7;--blue-dk:#004e8e;--blue-lt:#e6f2fb;--gray-100:#f1f4f7;--gray-200:#e2e8ee;--gray-400:#8fa3b4;--gray-600:#4f6272;--gray-900:#192330}' +
    '*{box-sizing:border-box}html,body{margin:0;padding:0}' +
    'body{font-family:"Fira Sans",Arial,sans-serif;font-size:11pt;line-height:1.6;color:var(--gray-900);background:#e9ecef;padding:24px 16px;min-height:100vh}' +
    '.qs-page{max-width:780px;margin:0 auto;background:#fff;border-radius:6px;box-shadow:0 8px 32px rgba(0,0,0,.10);padding:46px 56px;min-height:1100px}' +
    '@media (max-width:640px){.qs-page{padding:30px 22px}}' +
    '.qs-cover{border-bottom:2px solid var(--blue);padding-bottom:14px;margin-bottom:24px}' +
    '.qs-cover-top{display:flex;justify-content:space-between;align-items:center}' +
    '.qs-ai-flag{font-size:.7rem;font-weight:600;background:#fef3c7;color:#92400e;border:1px solid #fcd34d;border-radius:12px;padding:2px 10px}' +
    '.qs-pill{display:inline-block;width:8px;height:18px;background:var(--blue);border-radius:8px;vertical-align:middle;margin-right:10px}' +
    '.qs-brand{font-family:"Fira Sans Condensed",sans-serif;font-weight:900;font-size:1.05rem;color:var(--blue);letter-spacing:-.02em;vertical-align:middle}' +
    '.qs-cover h1{font-family:"Fira Sans Condensed",sans-serif;font-weight:900;font-size:1.85rem;letter-spacing:-.02em;line-height:1.1;color:var(--gray-900);margin:14px 0 4px}' +
    '.qs-cover .qs-sub{color:var(--gray-600);font-size:.95rem;margin:0}' +
    '.qs-body h1,.qs-body h2,.qs-body h3,.qs-body h4{font-family:"Fira Sans Condensed",sans-serif;font-weight:800;letter-spacing:-.02em;color:var(--gray-900)}' +
    '.qs-body h1{font-size:1.35rem;margin:24px 0 8px}' +
    '.qs-body h2{font-size:1.1rem;margin:20px 0 6px;color:var(--blue)}' +
    '.qs-body h3{font-size:.98rem;margin:16px 0 4px}' +
    '.qs-body h4{font-size:.9rem;margin:12px 0 4px;color:var(--gray-600)}' +
    '.qs-body p{margin:0 0 8px}' +
    '.qs-body ul,.qs-body ol{margin:0 0 10px 18px;padding:0}' +
    '.qs-body li{margin-bottom:3px}' +
    '.qs-body li::marker{color:var(--blue)}' +
    '.qs-body strong{font-weight:600}' +
    '.qs-body a{color:var(--blue);text-decoration:none}' +
    '.qs-body table{width:100%;border-collapse:collapse;margin:10px 0 14px;font-size:.85rem}' +
    '.qs-body th,.qs-body td{text-align:left;padding:7px 10px;border-bottom:1px solid var(--gray-200);vertical-align:top}' +
    '.qs-body th{font-family:"Fira Sans Condensed",sans-serif;font-weight:800;background:var(--blue-lt);color:var(--blue-dk);border-bottom:2px solid var(--blue);text-transform:uppercase;font-size:.75rem;letter-spacing:.04em}' +
    '.qs-body tr:last-child td{border-bottom:0}' +
    '.qs-body code{font-family:"JetBrains Mono",ui-monospace,monospace;font-size:.85rem;background:var(--gray-100);padding:1px 5px;border-radius:3px;color:var(--blue-dk)}' +
    '.qs-body pre{background:var(--gray-100);border-left:3px solid var(--blue);padding:10px 12px;border-radius:4px;overflow-x:auto;font-size:.85rem}' +
    '.qs-body pre code{background:transparent;padding:0;color:var(--gray-900)}' +
    '.qs-body blockquote{border-left:3px solid var(--blue);background:var(--blue-lt);margin:12px 0;padding:8px 14px;color:var(--gray-600);font-style:italic}' +
    '.qs-body hr{border:0;border-top:1px solid var(--gray-200);margin:18px 0}' +
    '.qs-foot{margin-top:32px;padding-top:14px;border-top:1px solid var(--gray-200);display:flex;justify-content:space-between;font-size:.72rem;color:var(--gray-400);font-family:"Fira Sans",Arial,sans-serif}' +
    '@media print{body{background:#fff;padding:0}.qs-page{box-shadow:none;border-radius:0;max-width:none;padding:32px}}' +
    '</style></head><body>' +
    '<div class="qs-page">' +
    '<div class="qs-cover"><div class="qs-cover-top"><span><span class="qs-pill"></span><span class="qs-brand">adCraft</span></span><span class="qs-ai-flag">🤖 KI-generiert</span></div>' +
    '<h1>' + t + '</h1>' +
    '<p class="qs-sub">Quick-Sheet</p></div>' +
    '<div class="qs-body">' + bodyHtml + '</div>' +
    '<div class="qs-foot"><span>adCraft &middot; Quick-Sheet</span><span>' + esc(new Date().toLocaleDateString('de-DE')) + '</span></div>' +
    '</div></body></html>';

  return Buffer.from(html, 'utf-8');
}


module.exports = { renderFlashcardsHtml, renderLearningPathHtml, renderQuickSheetHtml };
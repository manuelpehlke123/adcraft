# adCraft

KI-gestützter Lernmaterial-Generator für Microsoft-Produkte.
Statisches HTML/CSS/JS Frontend + Node.js/Express Backend mit
sauberer Provider-Abstraktion (Claude heute, OpenAI/Gemini später).

## Setup

```bash
cd adcraft
npm install
cp .env.example .env
# In .env eintragen:
#   ADESSO_AIHUB_API_KEY    (aus dem AI Hub Portal)
#   ADESSO_AIHUB_BASE_URL   (https://adesso-ai-hub.../v1)
#   ADESSO_AIHUB_MODEL      (z.B. claude-opus-4-7)
npm start
```

Dann: http://localhost:3000

> **Sicherheit:** Der API-Key gehört ausschließlich in `.env` (lokal) bzw. in
> die App Settings deiner Azure Web App (produktiv). Niemals einchecken,
> niemals in Chats / Tickets / Code-Reviews kopieren. Bei Verdacht auf
> Kompromittierung: Key im AI Hub rotieren.

## Projektstruktur

```
adcraft/
├── server.js                 # Express-Server, REST-API
├── sources.js                # Ingestion: Text / PDF / Bild / URL
├── prompts.js                # Prompt-Bibliothek (hier neue Formate ergänzen)
├── pdfRenderer.js            # Markdown -> branded PDF (Puppeteer)
├── htmlRenderer.js           # Format-spezifische HTML-Renderer (z.B. Karteikarten-Deck)
├── pptxRenderer.js           # JSON-Slide-Spec -> editierbare .pptx (pptxgenjs)
├── providers/
│   ├── base.js               # LLMProvider-Interface (Text)
│   ├── imageBase.js          # ImageProvider-Interface (Bilder)
│   ├── adessoAiHub.js        # adesso AI Hub (OpenAI-kompatibel) — DEFAULT Text
│   ├── anthropic.js          # Anthropic direkt
│   ├── gemini.js             # Google Gemini Text
│   ├── geminiImage.js        # Google Gemini Bild — DEFAULT Image
│   └── index.js              # Factories: getProvider() + getImageProvider()
├── public/
│   ├── index.html            # UI
│   ├── styles.css
│   └── app.js                # Frontend-Logik (vanilla JS, kein Build)
└── .env.example
```

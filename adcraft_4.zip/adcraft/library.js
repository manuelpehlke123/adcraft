const fs   = require('fs');
const path = require('path');
const { v4: uuid } = require('uuid');

const DIR = path.join(__dirname, '../data/library');
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true });

function list() {
  return fs.readdirSync(DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => { try { return JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8')); } catch { return null; } })
    .filter(Boolean)
    .sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));
}
function save(entry) {
  const id   = entry.id || uuid();
  const data = { ...entry, id, savedAt: new Date().toISOString() };
  fs.writeFileSync(path.join(DIR, `${id}.json`), JSON.stringify(data, null, 2));
  return data;
}
function get(id) {
  const file = path.join(DIR, `${id}.json`);
  if (!fs.existsSync(file)) return null;
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}
function update(id, patch) {
  const existing = get(id);
  if (!existing) return null;
  const updated = { ...existing, ...patch, updatedAt: new Date().toISOString() };
  fs.writeFileSync(path.join(DIR, `${id}.json`), JSON.stringify(updated, null, 2));
  return updated;
}
function remove(id) {
  const file = path.join(DIR, `${id}.json`);
  if (fs.existsSync(file)) fs.unlinkSync(file);
}

module.exports = { list, save, get, update, remove };
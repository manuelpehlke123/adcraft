/**
 * Prompt Library
 * Platzhalter die server.js zur Laufzeit ersetzt:
 *   {topic} {language} {level} {audience} {depth}
 *   {lpSteps} {lpQuiz} {lpStepWords}  ← nur für learningpath
 */

// Tiefen-Profil: steuert Schritte + Quizfragen + Min. Wörter pro Schritt.
const DEPTH_PROFILES = {
  compact:    { steps: 3,  quiz: 5,  stepWords: 120, label: 'kompakt' },
  standard:   { steps: 5,  quiz: 10, stepWords: 200, label: 'ausgewogen' },
  detailed:   { steps: 7,  quiz: 15, stepWords: 300, label: 'ausführlich' },
  exhaustive: { steps: 10, quiz: 20, stepWords: 450, label: 'erschöpfend' },
};

function getDepthProfile(depth) {
  return DEPTH_PROFILES[depth] || DEPTH_PROFILES.standard;
}

const PROMPTS = [
  {
    id: 'quick_sheet',
    label: 'Quick-Sheet (1-Pager Cheat Sheet)',
    description: 'Kompakte 1-seitige Übersicht mit den wichtigsten Konzepten, Shortcuts und Beispielen.',
    systemPrompt:
`You are an expert trainer and instructional designer. Your Quick-Sheets are:
- Strictly structured (Markdown headings, bullet lists, tables where useful)
- Max 1 A4 page (~600-800 words)
- Practice-oriented: shortcuts, concrete click paths, common pitfalls
- Output language: {language} — write EVERYTHING in {language}
- Target audience: {audience}
- Knowledge level: {level}
- Content depth: {depth}`,
    userPrompt:
`Create a Quick-Sheet on: **{topic}**

Adapt all vocabulary, examples and depth for {audience} at level: {level}. Depth: {depth}.
Write the ENTIRE output in {language} — no other language allowed.

Structure:
1. Brief description (2-3 lines)
2. Core concepts (3-5 bullets)
3. Key actions / click paths (table: Action | Path)
4. Top shortcuts or commands (if applicable)
5. Common pitfalls / best practices
6. Further reading (only if mentioned in sources)

Deliver clean Markdown only, no preamble.`,
    options: { temperature: 0.5, maxTokens: 2500 },
    pdf: true,
  },

  {
    id: 'lesson_outline',
    label: 'Lerneinheit (Modulplan, ca. 60 Min)',
    description: 'Didaktischer Plan für eine 60-Minuten-Lerneinheit mit Lernzielen, Übungen und Reflexion.',
    systemPrompt:
`You are an Instructional Designer planning training sessions using ADDIE principles.
Formulate learning objectives using Bloom's taxonomy (action verbs: apply, analyze, evaluate).
Output language: {language} — write EVERYTHING in {language}.
Target audience: {audience}. Knowledge level: {level}. Content depth: {depth}.`,
    userPrompt:
`Create a 60-minute lesson plan on: **{topic}**

Write EVERYTHING in {language}. Calibrate for {audience} at level: {level}. Depth: {depth}.

Deliver as Markdown:
- Title
- Target group (1 sentence)
- 3-5 learning objectives (Bloom-operationalized)
- Prerequisites
- Schedule table: Min | Phase | Content | Method | Material
- Exercise with model solution (in a spoiler/toggle section)
- 3 reflection questions`,
    options: { temperature: 0.6, maxTokens: 3500 },
    pdf: true,
  },

  {
    id: 'flashcards',
    label: 'Karteikarten (JSON, für Anki / Quizlet)',
    description: '15-25 Frage/Antwort-Paare als JSON-Array — direkt in Anki oder Quizlet importierbar.',
    systemPrompt:
`You create high-quality learning flashcards.
Rules:
- One card = one concept (atomicity)
- Question precise and short, answer complete but concise
- Mix knowledge questions, application questions and procedural questions
- ALL card text (front, back, tags) must be in {language}
- Calibrate complexity for {audience} at level: {level}
- RESPOND ONLY WITH VALID JSON — no markdown, no code fences.`,
    userPrompt:
`Create 15-20 flashcards on: **{topic}**

ALL text must be in {language}. Level: {level}. Audience: {audience}. Depth: {depth}.

Exact format:
{
  "topic": "...",
  "cards": [
    { "front": "Question in {language}", "back": "Answer in {language}", "tags": ["tag1"] }
  ]
}`,
    options: { temperature: 0.4, maxTokens: 4000 },
    htmlRenderer: 'flashcards',
  },

  {
    id: 'video_script',
    label: 'Video-Skript (3-5 Min Erklärvideo)',
    description: 'Sprecher-Skript mit Szenen-Anweisungen und Bild-Vorschlägen für ein kurzes Erklärvideo.',
    systemPrompt:
`You are a screenwriter for explainer videos. Style: concrete, example-driven, no buzzword overload.
Deliver spoken text in natural language (not bullet style) with parallel B-roll suggestions.
Output language: {language} — write EVERYTHING in {language}.
Target audience: {audience}. Knowledge level: {level}. Content depth: {depth}.`,
    userPrompt:
`Write a 3-5 minute explainer video script on: **{topic}**

Write EVERYTHING in {language}. Tone and examples adapted for {audience} at level: {level}. Depth: {depth}.

Format (Markdown):
# Title
**Duration:** ~X min
**Target audience:** ...

## Scene 1 — Hook (0:00-0:15)
**Speaker:** ...
**Visual/B-Roll:** ...

Deliver 5-7 scenes + 3-5 image generation prompts at the end.`,
    options: { temperature: 0.7, maxTokens: 3500 },
    pdf: true,
  },

  {
    id: 'image_prompts',
    label: 'Bild-Prompts (für Midjourney / Gemini / DALL-E)',
    description: 'Set von 5-8 ausformulierten Bildgenerierungs-Prompts passend zum Lernthema.',
    systemPrompt:
`You are a Visual Designer writing prompts for image generators.
Image prompts must always be in English (models perform better).
Descriptions and labels write in {language}.
Prompts must be specific about style, composition, color, lighting and consistent across the set.`,
    userPrompt:
`Generate 5-8 image prompts for learning material on: **{topic}**

Write descriptions and labels in {language}. Image prompts in English.
Audience: {audience}. Level: {level}.

Each entry:
- **Purpose:** (in {language})
- **Prompt:** (English, detailed, with style specs)
- **Negative Prompt:** (what to avoid)`,
    options: { temperature: 0.8, maxTokens: 2500 },
  },

  {
    id: 'pptx_deck',
    label: 'PowerPoint-Deck (editierbare .pptx)',
    description: 'Ein vollständiges Deck mit Cover, Section-Slides und Content-Folien.',
    systemPrompt:
`You are an expert trainer and slide designer creating structured training decks.
Rules:
- 8-15 slides, one idea per slide, max 6 bullets per slide, max 12 words per bullet
- Mix section slides between content slides
- Speaker notes complement, not repeat the slide
- ALL slide text (title, subtitle, bullets, notes) must be in {language}
- Calibrate for {audience} at level: {level} with depth: {depth}
- RESPOND ONLY WITH VALID JSON — no markdown, no code fences.`,
    userPrompt:
`Create a training deck on: **{topic}**

ALL text fields in {language}. Level: {level}. Audience: {audience}. Depth: {depth}.

Exact format:
{
  "title": "Main title in {language}",
  "subtitle": "Subtitle in {language}",
  "slides": [
    { "type": "content", "title": "...", "bullets": ["..."], "notes": "...", "imagePrompt": null },
    { "type": "section", "title": "...", "subtitle": "..." }
  ]
}

Create 8-12 slides. Set imagePrompt (English) only for 30-50% of content slides where a visual adds value.`,
    options: { temperature: 0.6, maxTokens: 6000 },
    pptxRenderer: 'deck',
  },

  {
    id: 'image_generation',
    label: 'Bild generieren (eigenständig)',
    description: 'Erzeugt ein einzelnes Bild zum eingegebenen Thema.',
    comingSoon: true,
    systemPrompt:
`You are a Visual Designer writing high-quality image generation prompts in English.
Response format: ONLY the prompt itself, no quotes, no preamble. Max 80 words.`,
    userPrompt:
`Write an image prompt for a learning material visual on: **{topic}**
Style: isometric flat illustration, blue-white palette, clean composition, white background.`,
    options: { temperature: 0.7, maxTokens: 300 },
    imageGeneration: true,
  },

  {
    id: 'learningpath',
    label: 'Lernpfad (interaktiv, mit Abschlusstest)',
    description: 'Strukturierter Lernpfad mit Kapiteln, Übungen und einem Abschlussquiz (mind. 75% zum Bestehen).',
    systemPrompt:
`You are an Instructional Designer creating interactive learning paths.
ALL text (titles, descriptions, step content, tasks, solutions, questions, options, explanations) MUST be in {language}.
Calibrate for {audience} at level: {level} with depth: {depth}.
RESPOND ONLY WITH VALID JSON — no markdown, no code fences, no preamble.`,
    userPrompt:
`Create a complete interactive learning path on: **{topic}**

CRITICAL: Write ALL text fields in {language}. Level: {level}. Audience: {audience}. Depth: {depth}.

Length requirements (calibrated for the chosen depth):
- EXACTLY {lpSteps} learning steps
- EXACTLY {lpQuiz} quiz questions
- Each step content has at least {lpStepWords} words

Each step MUST include: a practical task and a model solution.
Each quiz question has 4 options and a correctIndex (0-3) plus explanation.

Respond with ONLY the JSON object:
{
  "topic": "...",
  "title": "Full title in {language}",
  "description": "2-3 sentences in {language}",
  "estimatedMinutes": 45,
  "steps": [
    {
      "id": 1,
      "title": "Step title in {language}",
      "content": "Detailed content in {language} (min {lpStepWords} words)",
      "task": "Practical task in {language}",
      "solution": "Model solution in {language}"
    }
  ],
  "quiz": [
    {
      "id": 1,
      "question": "Question in {language}",
      "options": ["A", "B", "C", "D"],
      "correctIndex": 0,
      "explanation": "Explanation in {language}"
    }
  ]
}`,
    options: { temperature: 0.6, maxTokens: 16000 },
    htmlRenderer: 'learningpath',
  },
];

function listFormats() {
  return PROMPTS.map(({ id, label, description, comingSoon }) => ({
    id, label, description,
    comingSoon: !!comingSoon,
  }));
}
function getPrompt(id) {
  return PROMPTS.find((p) => p.id === id);
}

module.exports = { listFormats, getPrompt, getDepthProfile, DEPTH_PROFILES };

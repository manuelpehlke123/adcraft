const { ImageProvider } = require('./imageBase');

/**
 * Gemini Image Provider
 * ---------------------
 * Uses Google's image generation models via the Gemini API:
 *   - "Nano Banana Pro" → gemini-3-pro-image-preview (newer, may need waitlist)
 *   - "Nano Banana"     → gemini-2.5-flash-image     (broadly available)
 *
 * Returns image bytes from the response's inlineData parts. Same
 * Generative Language API endpoint as the text provider.
 *
 * Required env:
 *   GEMINI_IMAGE_API_KEY (can reuse GEMINI_API_KEY)
 *   GEMINI_IMAGE_MODEL   (e.g. gemini-2.5-flash-image)
 */
class GeminiImageProvider extends ImageProvider {
  constructor({ apiKey, defaultModel = 'gemini-2.5-flash-image' }) {
    super();
    if (!apiKey) {
      throw new Error('GeminiImageProvider: API key is required');
    }
    this.apiKey = apiKey;
    this.defaultModel = defaultModel;
    this.baseUrl = 'https://generativelanguage.googleapis.com/v1beta';
  }

  getName() {
    return 'gemini-image';
  }

  async generateImage({ prompt, options = {} }) {
    if (!prompt) throw new Error('prompt is required');
    const model = options.model || this.defaultModel;

    const body = {
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      // The image-output models return image data in the response parts
      // when generationConfig.responseModalities includes IMAGE.
      generationConfig: {
        responseModalities: ['IMAGE'],
      },
    };

    const url = `${this.baseUrl}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(this.apiKey)}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(
        `Gemini Image HTTP ${res.status}: ${truncate(txt, 500) || res.statusText}`
      );
    }

    const data = await res.json();
    const parts = data.candidates?.[0]?.content?.parts || [];
    const imagePart = parts.find((p) => p.inlineData?.data);

    if (!imagePart) {
      // The model may have refused (safety) or returned only text
      const textRefusal = parts.find((p) => p.text)?.text;
      throw new Error(
        textRefusal
          ? `Gemini Image lieferte keinen Bilddaten-Teil zurück: ${truncate(textRefusal, 200)}`
          : 'Gemini Image lieferte keinen Bilddaten-Teil zurück (Modell verfügbar?)'
      );
    }

    const buffer = Buffer.from(imagePart.inlineData.data, 'base64');
    const mediaType = imagePart.inlineData.mimeType || 'image/png';

    return { buffer, mediaType, model, prompt };
  }
}

function truncate(s, n) {
  return s && s.length > n ? s.slice(0, n) + '…' : s;
}

module.exports = { GeminiImageProvider };

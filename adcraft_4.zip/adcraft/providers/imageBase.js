/**
 * Image Provider Abstraction
 * --------------------------
 * Separate from LLMProvider because text and image generation often live
 * with different vendors, models, and pricing units.
 *
 * Implementations must return { buffer, mediaType, model, prompt } where
 * buffer is the raw image bytes (PNG or JPEG).
 */

class ImageProvider {
  /**
   * Generate an image from a prompt.
   * @param {Object} params
   * @param {string} params.prompt
   * @param {Object} [params.options] - { aspectRatio, model, ... }
   * @returns {Promise<{ buffer: Buffer, mediaType: string, model: string, prompt: string }>}
   */
  async generateImage(params) {
    throw new Error('generateImage() must be implemented by provider');
  }

  getName() {
    throw new Error('getName() must be implemented by provider');
  }
}

module.exports = { ImageProvider };

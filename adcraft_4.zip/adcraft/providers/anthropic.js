const Anthropic = require('@anthropic-ai/sdk');
const { LLMProvider } = require('./base');

class AnthropicProvider extends LLMProvider {
  constructor({ apiKey, defaultModel = 'claude-opus-4-7' }) {
    super();
    if (!apiKey) {
      throw new Error('AnthropicProvider: ANTHROPIC_API_KEY is required');
    }
    this.client = new Anthropic({ apiKey });
    this.defaultModel = defaultModel;
  }

  getName() {
    return 'anthropic';
  }

  /**
   * Sources may now be:
   *   { type: 'text' | 'pdf' | 'url', name, content }       // textual content
   *   { type: 'image', name, mediaType, data }              // data = base64 (no prefix)
   */
  async generateText({ systemPrompt, userPrompt, sources = [], options = {} }) {
    const model = options.model || this.defaultModel;
    const maxTokens = options.maxTokens || 4096;
    const temperature = options.temperature ?? 0.7;

    const textSources = sources.filter((s) => s.type !== 'image');
    const imageSources = sources.filter((s) => s.type === 'image');

    const textBlock = textSources.length
      ? textSources
          .map(
            (s, i) =>
              `<source index="${i + 1}" type="${s.type}" name="${escapeAttr(s.name)}">\n${s.content}\n</source>`
          )
          .join('\n\n')
      : '';

    // Build the multimodal user content array
    const userContent = [];

    // Images first — Claude handles vision-then-text best
    for (const img of imageSources) {
      userContent.push({
        type: 'image',
        source: {
          type: 'base64',
          media_type: img.mediaType,
          data: img.data,
        },
      });
      userContent.push({
        type: 'text',
        text: `↑ Screenshot/Bild: "${img.name}"`,
      });
    }

    const taskText = textBlock
      ? `Hier sind die Quellen, auf die du dich stützen sollst:\n\n${textBlock}\n\n---\n\nAufgabe:\n${userPrompt}`
      : userPrompt;

    userContent.push({ type: 'text', text: taskText });

    const response = await this.client.messages.create({
      model,
      max_tokens: maxTokens,
      temperature,
      system: systemPrompt,
      messages: [{ role: 'user', content: userContent }],
    });

    const text = response.content
      .filter((b) => b.type === 'text')
      .map((b) => b.text)
      .join('\n');

    return {
      text,
      usage: response.usage,
      model: response.model,
    };
  }
}

function escapeAttr(s) {
  return String(s).replaceAll('"', '&quot;').replaceAll('<', '&lt;');
}

module.exports = { AnthropicProvider };

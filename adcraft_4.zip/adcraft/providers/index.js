const { AnthropicProvider } = require('./anthropic');
const { AdessoAIHubProvider } = require('./adessoAiHub');
const { GeminiProvider } = require('./gemini');
const { GeminiImageProvider } = require('./geminiImage');

/**
 * Returns the configured TEXT provider (LLMProvider).
 *
 * Switched via env LLM_PROVIDER:
 *   adesso-ai-hub (default), anthropic, gemini
 */
function getProvider(name) {
  const providerName = (name || process.env.LLM_PROVIDER || 'adesso-ai-hub').toLowerCase();

  switch (providerName) {
    case 'adesso-ai-hub':
      return new AdessoAIHubProvider({
        apiKey: process.env.ADESSO_AIHUB_API_KEY,
        baseUrl: process.env.ADESSO_AIHUB_BASE_URL,
        defaultModel: process.env.ADESSO_AIHUB_MODEL || 'claude-opus-4-6',
      });

    case 'anthropic':
      return new AnthropicProvider({
        apiKey: process.env.ANTHROPIC_API_KEY,
        defaultModel: process.env.ANTHROPIC_MODEL || 'claude-opus-4-7',
      });

    case 'gemini':
      return new GeminiProvider({
        apiKey: process.env.GEMINI_API_KEY,
        defaultModel: process.env.GEMINI_MODEL || 'gemini-2.5-pro',
      });

    default:
      throw new Error(`Unknown LLM provider: ${providerName}`);
  }
}

/**
 * Returns the configured IMAGE provider (ImageProvider).
 *
 * Switched via env IMAGE_PROVIDER:
 *   gemini-image (default)
 *
 * Independent of the text provider so users can mix-and-match
 * (e.g. AI Hub for text, Gemini for images).
 */
function getImageProvider(name) {
  const providerName = (name || process.env.IMAGE_PROVIDER || 'gemini-image').toLowerCase();

  switch (providerName) {
    case 'gemini-image':
      return new GeminiImageProvider({
        // Falls back to GEMINI_API_KEY if no dedicated image key is set
        apiKey: process.env.GEMINI_IMAGE_API_KEY || process.env.GEMINI_API_KEY,
        defaultModel: process.env.GEMINI_IMAGE_MODEL || 'gemini-2.5-flash-image',
      });

    default:
      throw new Error(`Unknown image provider: ${providerName}`);
  }
}

module.exports = { getProvider, getImageProvider };

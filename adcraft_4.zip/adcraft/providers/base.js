/**
 * LLM Provider Abstraction Layer
 * --------------------------------
 * Every provider (Anthropic, OpenAI, Gemini, ...) implements this contract.
 * The rest of the app NEVER imports a concrete provider directly — it only
 * uses what comes back from getProvider() in ./index.js.
 *
 * To add a new provider later:
 *   1. Create providers/openai.js that extends LLMProvider
 *   2. Register it in providers/index.js
 *   3. Set LLM_PROVIDER=openai in .env
 * No other code needs to change.
 */

class LLMProvider {
  /**
   * Generate text from a prompt, optionally grounded in source documents.
   * @param {Object} params
   * @param {string} params.systemPrompt - role/instruction for the model
   * @param {string} params.userPrompt   - user-facing instruction
   * @param {Array<{name:string, content:string}>} params.sources - source docs
   * @param {Object} [params.options]    - { maxTokens, temperature, model }
   * @returns {Promise<{text: string, usage: object, model: string}>}
   */
  async generateText(params) {
    throw new Error('generateText() must be implemented by provider');
  }

  /**
   * Return identifier for logs / UI.
   * @returns {string}
   */
  getName() {
    throw new Error('getName() must be implemented by provider');
  }
}

module.exports = { LLMProvider };

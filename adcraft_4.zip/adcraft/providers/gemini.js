const { LLMProvider } = require('./base');

/**
 * Google Gemini Provider (AI Studio API key path)
 * -----------------------------------------------
 * Uses the public Generative Language API:
 *   https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
 *
 * Auth is a single API key as `?key=...` query param. Fine for dev / single-user
 * scenarios. For Vertex AI / Service Account auth, build a separate provider —
 * the wire format differs slightly.
 *
 * Required env:
 *   GEMINI_API_KEY
 *   GEMINI_MODEL          (e.g. gemini-2.5-pro)
 *
 * Vision: images go in `inlineData` blocks, same as the SDK does.
 */
class GeminiProvider extends LLMProvider {
  constructor({ apiKey, defaultModel = 'gemini-2.5-pro' }) {
    super();
    if (!apiKey) {
      throw new Error('GeminiProvider: GEMINI_API_KEY is required');
    }
    this.apiKey = apiKey;
    this.defaultModel = defaultModel;
    this.baseUrl = 'https://generativelanguage.googleapis.com/v1beta';
  }

  getName() {
    return 'gemini';
  }

  async generateText({ systemPrompt, userPrompt, sources = [], options = {} }) {
    const model = options.model || this.defaultModel;
    const maxTokens = options.maxTokens || 4096;
    const temperature = options.temperature ?? 0.7;

    const textSources = sources.filter((s) => s.type !== 'image');
    const imageSources = sources.filter((s) => s.type === 'image');

    const textBlock = textSources.length
      ? textSources
          .map(
            (s, i) =>
              `<source index="${i + 1}" type="${s.type}" name="${escapeAttr(s.name)}">\n${s.content}\n</source>`
          )
          .join('\n\n')
      : '';

    // Gemini wants alternating role:user/model + parts: [{text|inlineData}]
    // System instructions are a separate top-level field.
    const parts = [];
    for (const img of imageSources) {
      parts.push({
        inlineData: {
          mimeType: img.mediaType,
          data: img.data,
        },
      });
      parts.push({ text: `↑ Screenshot/Bild: "${img.name}"` });
    }

    const taskText = textBlock
      ? `Hier sind die Quellen, auf die du dich stützen sollst:\n\n${textBlock}\n\n---\n\nAufgabe:\n${userPrompt}`
      : userPrompt;

    parts.push({ text: taskText });

    const body = {
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: 'user', parts }],
      generationConfig: {
        temperature,
        maxOutputTokens: maxTokens,
      },
    };

    const url = `${this.baseUrl}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(this.apiKey)}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`Gemini HTTP ${res.status}: ${truncate(txt, 500) || res.statusText}`);
    }

    const data = await res.json();
    const candidate = data.candidates?.[0];
    if (!candidate) throw new Error('Gemini response had no candidates');

    const text = (candidate.content?.parts || [])
      .map((p) => p.text || '')
      .join('\n')
      .trim();

    return {
      text,
      // Map Gemini usage to our common shape
      usage: data.usageMetadata
        ? {
            input_tokens: data.usageMetadata.promptTokenCount,
            output_tokens: data.usageMetadata.candidatesTokenCount,
          }
        : null,
      model,
    };
  }
}

function escapeAttr(s) {
  return String(s).replaceAll('"', '&quot;').replaceAll('<', '&lt;');
}
function truncate(s, n) {
  return s && s.length > n ? s.slice(0, n) + '…' : s;
}

module.exports = { GeminiProvider };

const { LLMProvider } = require('./base');

/**
 * Adesso AI Hub Provider
 * ----------------------
 * Speaks the OpenAI-compatible /v1/chat/completions schema.
 * The hub gateways multiple model families (incl. Anthropic Claude) behind
 * one OpenAI-style endpoint, so we treat it like any OpenAI-compatible API.
 *
 * Required env:
 *   ADESSO_AIHUB_API_KEY
 *   ADESSO_AIHUB_BASE_URL    (e.g. https://adesso-ai-hub.example/v1)
 *   ADESSO_AIHUB_MODEL       (e.g. claude-opus-4-7)
 *
 * Multimodal:
 *   Images are sent as { type: "image_url", image_url: { url: "data:..." } }
 *   which is the OpenAI-compatible vision format.
 */
class AdessoAIHubProvider extends LLMProvider {
  constructor({ apiKey, baseUrl, defaultModel }) {
    super();
    if (!apiKey) {
      throw new Error('AdessoAIHubProvider: ADESSO_AIHUB_API_KEY is required');
    }
    if (!baseUrl) {
      throw new Error('AdessoAIHubProvider: ADESSO_AIHUB_BASE_URL is required');
    }
    if (!defaultModel) {
      throw new Error('AdessoAIHubProvider: ADESSO_AIHUB_MODEL is required');
    }
    this.apiKey = apiKey;
    // Normalize: strip trailing slash. Endpoint becomes `${baseUrl}/chat/completions`.
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.defaultModel = defaultModel;
  }

  getName() {
    return 'adesso-ai-hub';
  }

  async generateText({ systemPrompt, userPrompt, sources = [], options = {} }) {
    const model = options.model || this.defaultModel;
    const maxTokens = options.maxTokens || 4096;
    const temperature = options.temperature ?? 0.7;

    const textSources = sources.filter((s) => s.type !== 'image');
    const imageSources = sources.filter((s) => s.type === 'image');

    const textBlock = textSources.length
      ? textSources
          .map(
            (s, i) =>
              `<source index="${i + 1}" type="${s.type}" name="${escapeAttr(s.name)}">\n${s.content}\n</source>`
          )
          .join('\n\n')
      : '';

    // Build OpenAI-style multimodal user content
    const userContent = [];

    for (const img of imageSources) {
      userContent.push({
        type: 'image_url',
        image_url: { url: `data:${img.mediaType};base64,${img.data}` },
      });
      userContent.push({
        type: 'text',
        text: `↑ Screenshot/Bild: "${img.name}"`,
      });
    }

    const taskText = textBlock
      ? `Hier sind die Quellen, auf die du dich stützen sollst:\n\n${textBlock}\n\n---\n\nAufgabe:\n${userPrompt}`
      : userPrompt;

    userContent.push({ type: 'text', text: taskText });

    const messages = [
      { role: 'system', content: systemPrompt },
      // If we only have plain text (no images), some gateways prefer a string content
      // over an array — but the array form is universally accepted, so we always use it.
      { role: 'user', content: userContent },
    ];

    const url = `${this.baseUrl}/chat/completions`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        max_tokens: maxTokens,
        temperature,
        // Stream: false for now — easy upgrade path later via SSE.
        stream: false,
      }),
    });

    if (!res.ok) {
      const bodyText = await res.text().catch(() => '');
      throw new Error(
        `AI Hub HTTP ${res.status}: ${truncate(bodyText, 500) || res.statusText}`
      );
    }

    const data = await res.json();

    // OpenAI-compatible response shape
    const choice = data.choices?.[0];
    if (!choice) {
      throw new Error('AI Hub response had no choices');
    }
    const text =
      typeof choice.message?.content === 'string'
        ? choice.message.content
        : Array.isArray(choice.message?.content)
        ? choice.message.content
            .filter((c) => c.type === 'text')
            .map((c) => c.text)
            .join('\n')
        : '';

    return {
      text,
      // Map OpenAI usage shape to the same field names as the Anthropic provider
      // so /api/generate output stays consistent.
      usage: data.usage
        ? {
            input_tokens: data.usage.prompt_tokens,
            output_tokens: data.usage.completion_tokens,
          }
        : null,
      model: data.model || model,
    };
  }
}

function escapeAttr(s) {
  return String(s).replaceAll('"', '&quot;').replaceAll('<', '&lt;');
}
function truncate(s, n) {
  return s && s.length > n ? s.slice(0, n) + '…' : s;
}

module.exports = { AdessoAIHubProvider };

/**
 * PDF Renderer
 * ------------
 * Markdown -> HTML (markdown-it) -> PDF (puppeteer/Chromium).
 *
 * Why not jsPDF / pdfkit? They make us reimplement layout, CJK, code blocks,
 * tables. Chromium already does it perfectly. The trade-off is the binary —
 * see notes in README about Azure deployment.
 *
 * The styling matches the adesso brand tokens used in the web UI:
 *   blue #006ec7, Fira Sans (Condensed for headings), 8/16px radii,
 *   gray-200 borders, blue-tinted accents.
 */

const MarkdownIt = require('markdown-it');

const md = new MarkdownIt({
  html: false,    // safe — never trust LLM output as raw HTML
  linkify: true,
  typographer: true,
  breaks: false,
});

let _browserPromise = null;
let _puppeteer = null;

/**
 * Lazy-load puppeteer + reuse a single browser instance across requests.
 * First call takes ~1-2s to launch Chromium; subsequent calls are <100ms.
 */
async function getBrowser() {
  if (!_browserPromise) {
    _puppeteer = require('puppeteer');
    _browserPromise = _puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
      ],
    });
  }
  return _browserPromise;
}

async function shutdown() {
  if (_browserPromise) {
    const browser = await _browserPromise;
    await browser.close().catch(() => {});
    _browserPromise = null;
  }
}

/**
 * Render markdown to PDF (Buffer).
 *
 * @param {Object} opts
 * @param {string} opts.markdown   - the body
 * @param {string} opts.title      - shown in the page header
 * @param {string} [opts.subtitle] - optional secondary line under title
 * @returns {Promise<Buffer>}
 */
async function renderMarkdownToPdf({ markdown, title, subtitle }) {
  const bodyHtml = md.render(markdown || '');
  const html = buildHtml({ title, subtitle, bodyHtml });

  const browser = await getBrowser();
  const page = await browser.newPage();
  try {
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '20mm', right: '18mm', bottom: '20mm', left: '18mm' },
      displayHeaderFooter: true,
      headerTemplate: `<div style="font-size:8px;width:100%;padding:0 18mm;color:#8fa3b4;font-family:Helvetica,Arial,sans-serif;">
        <span style="float:left;">${escapeHtml(title)}</span>
      </div>`,
      footerTemplate: `<div style="font-size:8px;width:100%;padding:0 18mm;color:#8fa3b4;font-family:Helvetica,Arial,sans-serif;">
        <span style="float:left;">adCraft · ${new Date().toLocaleDateString('de-DE')}</span>
        <span style="float:right;">Seite <span class="pageNumber"></span> / <span class="totalPages"></span></span>
      </div>`,
    });
    return Buffer.from(pdf);
  } finally {
    await page.close();
  }
}

function buildHtml({ title, subtitle, bodyHtml }) {
  return `<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300;400;600;700&family=Fira+Sans+Condensed:wght@700;800;900&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --blue: #006ec7;
    --blue-dk: #004e8e;
    --blue-lt: #e6f2fb;
    --gray-100: #f1f4f7;
    --gray-200: #e2e8ee;
    --gray-400: #8fa3b4;
    --gray-600: #4f6272;
    --gray-900: #192330;
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    font-family: "Fira Sans", Arial, sans-serif;
    font-size: 10.5pt;
    line-height: 1.55;
    color: var(--gray-900);
  }

  /* Cover header */
  .cover {
    border-bottom: 2px solid var(--blue);
    padding-bottom: 14px;
    margin-bottom: 28px;
  }
  .cover-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .cover .ai-flag {
    font-size: 8.5pt;
    font-weight: 600;
    background: #fef3c7;
    color: #92400e;
    border: 1px solid #fcd34d;
    border-radius: 12px;
    padding: 2px 10px;
  }
  .cover .pill {
    display: inline-block;
    width: 8px; height: 18px;
    background: var(--blue);
    border-radius: 8px;
    vertical-align: middle;
    margin-right: 10px;
  }
  .cover .brand {
    font-family: "Fira Sans Condensed", sans-serif;
    font-weight: 900;
    font-size: 16pt;
    color: var(--blue);
    letter-spacing: -0.02em;
    vertical-align: middle;
  }
  .cover h1 {
    font-family: "Fira Sans Condensed", sans-serif;
    font-weight: 900;
    font-size: 26pt;
    letter-spacing: -0.02em;
    line-height: 1.1;
    color: var(--gray-900);
    margin: 14px 0 4px;
  }
  .cover .subtitle {
    color: var(--gray-600);
    font-size: 11pt;
    margin: 0;
  }

  /* Body typography */
  h1, h2, h3, h4 {
    font-family: "Fira Sans Condensed", sans-serif;
    font-weight: 800;
    letter-spacing: -0.02em;
    color: var(--gray-900);
    page-break-after: avoid;
  }
  h1 { font-size: 18pt; margin: 28px 0 8px; }
  h2 { font-size: 14pt; margin: 22px 0 6px; color: var(--blue); }
  h3 { font-size: 12pt; margin: 18px 0 4px; }
  h4 { font-size: 10.5pt; margin: 14px 0 4px; color: var(--gray-600); }

  p { margin: 0 0 8px; }
  ul, ol { margin: 0 0 10px 18px; padding: 0; }
  li { margin-bottom: 3px; }
  li::marker { color: var(--blue); }

  strong { font-weight: 600; }
  a { color: var(--blue); text-decoration: none; }

  /* Tables */
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0 14px;
    font-size: 9.5pt;
    page-break-inside: avoid;
  }
  th, td {
    text-align: left;
    padding: 7px 10px;
    border-bottom: 1px solid var(--gray-200);
    vertical-align: top;
  }
  th {
    font-family: "Fira Sans Condensed", sans-serif;
    font-weight: 800;
    background: var(--blue-lt);
    color: var(--blue-dk);
    border-bottom: 2px solid var(--blue);
    text-transform: uppercase;
    font-size: 8.5pt;
    letter-spacing: 0.04em;
  }
  tr:last-child td { border-bottom: 0; }

  /* Code */
  code {
    font-family: "JetBrains Mono", monospace;
    font-size: 9pt;
    background: var(--gray-100);
    padding: 1px 5px;
    border-radius: 3px;
    color: var(--blue-dk);
  }
  pre {
    background: var(--gray-100);
    border-left: 3px solid var(--blue);
    padding: 10px 12px;
    border-radius: 4px;
    overflow: hidden;
    page-break-inside: avoid;
  }
  pre code {
    background: transparent;
    padding: 0;
    color: var(--gray-900);
  }

  /* Blockquote */
  blockquote {
    border-left: 3px solid var(--blue);
    background: var(--blue-lt);
    margin: 12px 0;
    padding: 8px 14px;
    color: var(--gray-600);
    font-style: italic;
    page-break-inside: avoid;
  }

  hr {
    border: 0;
    border-top: 1px solid var(--gray-200);
    margin: 18px 0;
  }
</style>
</head>
<body>
  <div class="cover">
    <div class="cover-top">
      <span class="cover-brand-row"><span class="pill"></span><span class="brand">adCraft</span></span>
      <span class="ai-flag">🤖 KI-generiert</span>
    </div>
    <h1>${escapeHtml(title)}</h1>
    ${subtitle ? `<p class="subtitle">${escapeHtml(subtitle)}</p>` : ''}
  </div>
  ${bodyHtml}
</body>
</html>`;
}

function escapeHtml(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

module.exports = { renderMarkdownToPdf, shutdown };
